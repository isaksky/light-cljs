//! Resolve the executable core to an arena with stable lexical binding IDs.

use std::{borrow::Cow, collections::HashMap, fmt, ops::Range};

use crate::interpreter::{CompilerLiteralKind, Form, FormKind, Source, ValueView};
use crate::macro_host::MacroHost;

use crate::{CollectionKind, NodeId, NodeKind, NumberKind, PrefixKind, SyntaxTree};

pub type Span = Range<usize>;

#[derive(Clone, Copy, Debug, Eq, PartialEq, Hash)]
pub struct ExprId(pub usize);

#[derive(Clone, Copy, Debug, Eq, PartialEq, Hash)]
pub struct LocalId(pub usize);

#[derive(Clone, Copy, Debug, Eq, PartialEq, Hash)]
pub struct StringId(pub usize);

#[derive(Clone, Copy, Debug, Eq, PartialEq, Hash)]
pub struct NamedLiteralId(pub usize);

/// Names share the owned UTF-16 table with strings, including generated names.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct NamedLiteral {
    pub namespace: Option<StringId>,
    pub name: StringId,
}

/// The finite executable JavaScript core; independent of interpreter Vars.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Hash)]
pub enum CoreFnId {
    Keyword,
    Symbol,
    Vector,
    List,
    HashMap,
    HashSet,
    Dissoc,
    Disj,
    Conj,
    Assoc,
    Seq,
    First,
    Rest,
    Next,
    Name,
    Namespace,
    Count,
    Nth,
    Get,
    Contains,
    Equal,
    Reduce,
    Add,
    Reduced,
    IsReduced,
    Unreduced,
    Deref,
    Meta,
    WithMeta,
    PrStr,
    Str,
    Identical,
    IsUuid,
    IsInst,
    InstMs,
    Uuid,
    RePattern,
    ReFind,
    ReMatches,
    ReSeq,
    IsRegex,
    Vec,
    Concat,
    Sequence,
    Apply,
    Into,
    IsVar,
}

impl CoreFnId {
    fn resolve(name: &str) -> Option<Self> {
        Some(match name {
            "keyword" => Self::Keyword,
            "symbol" => Self::Symbol,
            "vector" => Self::Vector,
            "list" => Self::List,
            "hash-map" => Self::HashMap,
            "hash-set" => Self::HashSet,
            "dissoc" => Self::Dissoc,
            "disj" => Self::Disj,
            "conj" => Self::Conj,
            "assoc" => Self::Assoc,
            "seq" => Self::Seq,
            "first" => Self::First,
            "rest" => Self::Rest,
            "next" => Self::Next,
            "name" => Self::Name,
            "namespace" => Self::Namespace,
            "count" => Self::Count,
            "nth" => Self::Nth,
            "get" => Self::Get,
            "contains?" => Self::Contains,
            "=" => Self::Equal,
            "reduce" => Self::Reduce,
            "+" => Self::Add,
            "reduced" => Self::Reduced,
            "reduced?" => Self::IsReduced,
            "unreduced" => Self::Unreduced,
            "deref" => Self::Deref,
            "meta" => Self::Meta,
            "with-meta" => Self::WithMeta,
            "pr-str" => Self::PrStr,
            "str" => Self::Str,
            "identical?" => Self::Identical,
            "uuid?" => Self::IsUuid,
            "inst?" => Self::IsInst,
            "inst-ms" => Self::InstMs,
            "uuid" => Self::Uuid,
            "re-pattern" => Self::RePattern,
            "re-find" => Self::ReFind,
            "re-seq" => Self::ReSeq,
            "re-matches" => Self::ReMatches,
            "regexp?" => Self::IsRegex,
            "vec" => Self::Vec,
            "concat" => Self::Concat,
            "sequence" => Self::Sequence,
            "apply" => Self::Apply,
            "into" => Self::Into,
            "var?" => Self::IsVar,
            "array-map" => Self::HashMap,
            _ => return None,
        })
    }

    pub(crate) fn runtime_name(self) -> &'static str {
        match self {
            Self::Keyword => "keyword",
            Self::Symbol => "symbol",
            Self::Vector => "vector",
            Self::List => "list",
            Self::HashMap => "hashMap",
            Self::HashSet => "hashSet",
            Self::Dissoc => "dissoc",
            Self::Disj => "disj",
            Self::Conj => "conj",
            Self::Assoc => "assoc",
            Self::Seq => "seq",
            Self::First => "first",
            Self::Rest => "rest",
            Self::Next => "next",
            Self::Name => "name",
            Self::Namespace => "namespace",
            Self::Count => "count",
            Self::Nth => "nth",
            Self::Get => "get",
            Self::Contains => "contains",
            Self::Equal => "equal",
            Self::Reduce => "reduce",
            Self::Add => "add",
            Self::Reduced => "reduced",
            Self::IsReduced => "isReduced",
            Self::Unreduced => "unreduced",
            Self::Deref => "deref",
            Self::Meta => "meta",
            Self::WithMeta => "withMeta",
            Self::PrStr => "prStr",
            Self::Str => "str",
            Self::Identical => "identical",
            Self::IsUuid => "isUuid",
            Self::IsInst => "isInst",
            Self::InstMs => "instMs",
            Self::Uuid => "uuid",
            Self::RePattern => "rePattern",
            Self::ReFind => "reFind",
            Self::ReSeq => "reSeq",
            Self::ReMatches => "reMatches",
            Self::IsRegex => "isRegex",
            Self::Vec => "vec",
            Self::Concat => "concat",
            Self::Sequence => "sequence",
            Self::Apply => "apply",
            Self::Into => "into",
            Self::IsVar => "isVar",
        }
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Hash)]
pub struct GlobalId(pub usize);

#[derive(Clone, Copy, Debug, Eq, PartialEq, Hash)]
pub struct JsGlobalId(pub usize);

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct GlobalBinding {
    pub metadata: Option<ExprId>,
    pub namespace: String,
    pub name: String,
    pub span: Span,
    pub source_index: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct JsGlobal {
    /// Validated ASCII JavaScript identifiers, never raw source interpolation.
    pub path: Vec<String>,
}

/// A namespace whose dependencies have already been placed earlier in the slice.
/// The caller validates its first `ns` form and the dependency graph.
pub struct NamespaceInput<'a> {
    pub name: &'a str,
    pub source: &'a str,
    pub syntax: &'a SyntaxTree,
    pub aliases: &'a [(String, String)],
    pub requires: &'a [String],
}

/// Both analysis (including native macro expansion) and emission track value use.
#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ExprContext {
    Value,
    Discard,
    Return,
}

#[derive(Clone, Debug, PartialEq)]
pub enum ExprKind {
    Nil,
    Bool(bool),
    Number(f64),
    String(StringId),
    ReaderLiteral {
        kind: CompilerLiteralKind,
        items: Vec<ExprId>,
    },
    WithMeta {
        value: ExprId,
        metadata: ExprId,
    },
    Var {
        value: ExprId,
        symbol: NamedLiteralId,
        metadata: Option<ExprId>,
    },
    Keyword(NamedLiteralId),
    Symbol(NamedLiteralId),
    List(Vec<ExprId>),
    Vector(Vec<ExprId>),
    Map(Vec<ExprId>),
    Set(Vec<ExprId>),
    CoreFn(CoreFnId),
    Local(LocalId),
    Global(GlobalId),
    JsGlobal(JsGlobalId),
    Def {
        global: GlobalId,
        init: Option<ExprId>,
    },
    Property {
        receiver: ExprId,
        property: String,
    },
    MethodCall {
        receiver: ExprId,
        method: String,
        args: Vec<ExprId>,
    },
    If {
        test: ExprId,
        yes: ExprId,
        no: ExprId,
    },
    Do(Vec<ExprId>),
    Let {
        bindings: Vec<(LocalId, ExprId)>,
        body: ExprId,
    },
    Fn {
        name: Option<LocalId>,
        params: Vec<LocalId>,
        rest: Option<LocalId>,
        body: ExprId,
    },
    Call {
        callee: ExprId,
        args: Vec<ExprId>,
    },
}

#[derive(Clone, Debug, PartialEq)]
pub struct Expr {
    pub kind: ExprKind,
    pub span: Span,
    pub context: ExprContext,
    pub source_index: usize,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct LocalBinding {
    /// Diagnostic spelling only. References and emitted names use LocalId.
    pub name: String,
    pub span: Span,
    pub source_index: usize,
}

#[derive(Clone, Debug, PartialEq)]
pub struct Program {
    pub exprs: Vec<Expr>,
    pub locals: Vec<LocalBinding>,
    pub globals: Vec<GlobalBinding>,
    pub js_globals: Vec<JsGlobal>,
    /// Owned UTF-16 preserves even lone surrogate escapes.
    pub strings: Vec<Vec<u16>>,
    pub named_literals: Vec<NamedLiteral>,
    pub root: ExprId,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum AnalysisErrorKind {
    UnresolvedSymbol(String),
    Unsupported(String),
    InvalidForm(&'static str),
    InvalidBinding,
    DuplicateParameter(String),
    NumberOutOfRange,
    MacroExpansion(String),
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct AnalysisError {
    pub kind: AnalysisErrorKind,
    pub span: Span,
}

impl fmt::Display for AnalysisError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match &self.kind {
            AnalysisErrorKind::UnresolvedSymbol(name) => write!(f, "unresolved symbol: {name}"),
            AnalysisErrorKind::Unsupported(what) => write!(f, "unsupported construct: {what}"),
            AnalysisErrorKind::InvalidForm(message) => f.write_str(message),
            AnalysisErrorKind::InvalidBinding => {
                f.write_str("binding must be an unqualified symbol without '.' and cannot be '&'")
            }
            AnalysisErrorKind::DuplicateParameter(name) => write!(f, "duplicate parameter: {name}"),
            AnalysisErrorKind::MacroExpansion(message) => write!(f, "macro expansion: {message}"),
            AnalysisErrorKind::NumberOutOfRange => {
                f.write_str("number is not a valid ClojureScript constant")
            }
        }
    }
}

impl std::error::Error for AnalysisError {}

// JVM reader data identity precedes JavaScript lowering: integers and doubles
// remain distinct, while vectors/lists compare by contents and maps unordered.
#[derive(Clone, Debug, Eq, PartialEq, Ord, PartialOrd)]
enum ReaderDatum {
    Nil,
    Bool(bool),
    Number(bool, String),
    ReaderLiteral(u8, String),
    String(Vec<u16>),
    Named(bool, Option<Vec<u16>>, Vec<u16>),
    Sequential(Vec<ReaderDatum>),
    Map(Vec<(ReaderDatum, ReaderDatum)>),
    Set(Vec<ReaderDatum>),
}

/// A scope holds IDs, while records live for the entire compilation unit.
#[derive(Default)]
struct Environment {
    scopes: Vec<Vec<LocalId>>,
}

struct Analyzer<'a> {
    source: &'a str,
    syntax: Cow<'a, SyntaxTree>,
    generated: Vec<Option<Form>>,
    discards: Vec<NodeId>,
    next_discard: usize,
    spellings: Vec<Option<String>>,
    numbers: Vec<Option<Option<f64>>>,
    local_kinds: HashMap<LocalId, (&'static str, Option<usize>)>,
    macro_host: &'a mut MacroHost,
    macro_depth: usize,
    analysis_depth: usize,
    macro_source: Option<Source>,
    program: Program,
    env: Environment,
    globals: HashMap<(String, String), GlobalId>,
    namespace: &'a str,
    aliases: &'a [(String, String)],
    requires: &'a [String],
    source_index: usize,
}

fn compiler_syntax<'a>(source: &str, syntax: &'a SyntaxTree) -> (Cow<'a, SyntaxTree>, Vec<NodeId>) {
    if !source.contains("#_")
        || !crate::Tokenizer::new(source).any(|token| token.kind == crate::TokenKind::Discard)
    {
        return (Cow::Borrowed(syntax), Vec::new());
    }
    // Only original source is parsed; semantic/native values are never reparsed.
    let mut parser = crate::Parser::new(source).retaining_discards();
    let mut roots = Vec::new();
    while let Some(root) = parser.read_form().expect("already validated source") {
        roots.push(root);
    }
    let mut discards = parser.discarded().to_vec();
    discards.sort_by_key(|id| parser.nodes()[id.0].span.start);
    (
        Cow::Owned(SyntaxTree {
            nodes: parser.into_nodes(),
            roots,
        }),
        discards,
    )
}

fn empty_program() -> Program {
    Program {
        exprs: Vec::new(),
        locals: Vec::new(),
        globals: Vec::new(),
        js_globals: Vec::new(),
        strings: Vec::new(),
        named_literals: Vec::new(),
        root: ExprId(0),
    }
}

/// Analyze a parser-produced tree against its exact original source buffer.
/// Standalone input has namespace `cljs.user`; filesystem loading is explicit.
pub fn analyze(source: &str, syntax: &SyntaxTree) -> Result<Program, AnalysisError> {
    analyze_with_macros(source, syntax, &mut MacroHost::new())
}

/// Analyze with an explicitly supplied native macro host and import configuration.
pub fn analyze_with_macros(
    source: &str,
    syntax: &SyntaxTree,
    macro_host: &mut MacroHost,
) -> Result<Program, AnalysisError> {
    macro_host.begin_compilation();
    let (syntax, discards) = compiler_syntax(source, syntax);
    let roots = syntax.roots.clone();
    let mut analyzer = Analyzer {
        source,
        syntax,
        discards,
        next_discard: 0,
        generated: Vec::new(),
        spellings: Vec::new(),
        numbers: Vec::new(),
        local_kinds: HashMap::new(),
        macro_host,
        macro_depth: 0,
        analysis_depth: 0,
        macro_source: None,
        program: empty_program(),
        env: Environment::default(),
        globals: HashMap::new(),
        namespace: "cljs.user",
        aliases: &[],
        requires: &[],
        source_index: 0,
    };
    analyzer.program.root = analyzer.body(&roots, 0..source.len(), ExprContext::Return)?;
    analyzer.read_discards_before(source.len())?;
    Ok(analyzer.program)
}

/// Analyze validated namespaces in dependency-first order into one shared unit.
pub fn analyze_namespaces(
    inputs: &[NamespaceInput<'_>],
) -> Result<Program, (usize, AnalysisError)> {
    analyze_namespaces_with_macros(inputs, &mut MacroHost::new())
}

pub fn analyze_namespaces_with_macros(
    inputs: &[NamespaceInput<'_>],
    macro_host: &mut MacroHost,
) -> Result<Program, (usize, AnalysisError)> {
    analyze_namespaces_prepared(inputs, macro_host, |_, _| Ok(()))
}

pub(crate) fn analyze_namespaces_prepared(
    inputs: &[NamespaceInput<'_>],
    macro_host: &mut MacroHost,
    mut prepare: impl FnMut(&mut MacroHost, usize) -> Result<(), AnalysisError>,
) -> Result<Program, (usize, AnalysisError)> {
    macro_host.begin_compilation();
    let mut program = empty_program();
    let mut globals = HashMap::new();
    let mut roots = Vec::new();
    for (source_index, input) in inputs.iter().enumerate() {
        prepare(macro_host, source_index).map_err(|error| (source_index, error))?;
        let (syntax, discards) = compiler_syntax(input.source, input.syntax);
        let source_roots = syntax.roots.clone();
        let mut analyzer = Analyzer {
            source: input.source,
            syntax,
            discards,
            next_discard: 0,
            generated: Vec::new(),
            spellings: Vec::new(),
            numbers: Vec::new(),
            local_kinds: HashMap::new(),
            macro_host,
            macro_depth: 0,
            analysis_depth: 0,
            macro_source: None,
            program,
            env: Environment::default(),
            globals,
            namespace: input.name,
            aliases: input.aliases,
            requires: input.requires,
            source_index,
        };
        let context = if source_index + 1 == inputs.len() {
            ExprContext::Return
        } else {
            ExprContext::Discard
        };
        let root = analyzer
            .body(&source_roots[1..], 0..input.source.len(), context)
            .map_err(|error| (source_index, error))?;
        analyzer
            .read_discards_before(input.source.len())
            .map_err(|e| (source_index, e))?;
        roots.push(root);
        program = analyzer.program;
        globals = analyzer.globals;
    }
    program.root = ExprId(program.exprs.len());
    program.exprs.push(Expr {
        kind: ExprKind::Do(roots),
        span: 0..0,
        context: ExprContext::Return,
        source_index: 0,
    });
    Ok(program)
}

impl Analyzer<'_> {
    fn push(&mut self, kind: ExprKind, span: Span, context: ExprContext) -> ExprId {
        let id = ExprId(self.program.exprs.len());
        self.program.exprs.push(Expr {
            kind,
            span,
            context,
            source_index: self.source_index,
        });
        id
    }

    fn error(&self, node: NodeId, kind: AnalysisErrorKind) -> AnalysisError {
        AnalysisError {
            kind,
            span: self.syntax.nodes[node.0].span.clone(),
        }
    }

    fn spelling(&self, node: NodeId) -> &str {
        self.spellings
            .get(node.0)
            .and_then(Option::as_deref)
            .unwrap_or_else(|| &self.source[self.syntax.nodes[node.0].span.clone()])
    }

    fn lookup(&self, name: &str) -> Option<LocalId> {
        self.env
            .scopes
            .iter()
            .rev()
            .flat_map(|scope| scope.iter().rev())
            .copied()
            .find(|id| self.program.locals[id.0].name == name)
    }

    fn binding_name(&self, node: NodeId) -> Result<&str, AnalysisError> {
        self.validate_symbol(node)?;
        let name = self.spelling(node);
        if !matches!(self.syntax.nodes[node.0].kind, NodeKind::Symbol)
            || (name != "/" && name.contains('/'))
            || name.contains('.')
            || name == "&"
        {
            return Err(self.error(node, AnalysisErrorKind::InvalidBinding));
        }
        Ok(name)
    }

    fn bind(&mut self, node: NodeId) -> Result<LocalId, AnalysisError> {
        let name = self.binding_name(node)?.to_owned();
        let id = LocalId(self.program.locals.len());
        self.program.locals.push(LocalBinding {
            name,
            span: self.syntax.nodes[node.0].span.clone(),
            source_index: self.source_index,
        });
        self.env.scopes.last_mut().expect("binding scope").push(id);
        Ok(id)
    }

    fn form(&mut self, id: NodeId, context: ExprContext) -> Result<ExprId, AnalysisError> {
        if self.macro_depth > 0 && self.analysis_depth >= 128 {
            return Err(self.error(
                id,
                AnalysisErrorKind::MacroExpansion(
                    "generated runtime form nesting limit exceeded".into(),
                ),
            ));
        }
        self.analysis_depth += 1;
        let result = self.form_inner(id, context);
        self.analysis_depth -= 1;
        result
    }

    fn form_inner(&mut self, id: NodeId, context: ExprContext) -> Result<ExprId, AnalysisError> {
        let node = self.syntax.nodes[id.0].clone();
        if self.generated.get(id.0).and_then(Option::as_ref).is_none() {
            self.read_discards_before(node.span.start)?;
        }
        if self.needs_reader(id) {
            let expanded = self.expand_reader(id)?;
            return self.form(expanded, context);
        }
        if let Some(form) = self.generated.get(id.0).and_then(Option::as_ref).cloned()
            && let ValueView::CompilerLiteral(kind) = form.data().inspect()
        {
            return self.reader_literal(&form, kind, context, false);
        }
        let kind = match &node.kind {
            NodeKind::Nil => ExprKind::Nil,
            NodeKind::Boolean(value) => ExprKind::Bool(*value),
            NodeKind::Number(kind) => {
                let value = self
                    .numbers
                    .get(id.0)
                    .copied()
                    .flatten()
                    .unwrap_or_else(|| number(self.spelling(id), *kind))
                    .ok_or_else(|| self.error(id, AnalysisErrorKind::NumberOutOfRange))?;
                ExprKind::Number(value)
            }
            NodeKind::Character(value) => {
                ExprKind::String(self.own_string(value.encode_utf16(&mut [0; 2]).to_vec()))
            }
            NodeKind::SymbolicValue(value) => ExprKind::Number(match value {
                crate::SymbolicValue::Infinity => f64::INFINITY,
                crate::SymbolicValue::NegativeInfinity => f64::NEG_INFINITY,
                crate::SymbolicValue::NaN => f64::NAN,
            }),
            NodeKind::String(value) => {
                let id = StringId(self.program.strings.len());
                self.program.strings.push(value.to_utf16(self.source));
                ExprKind::String(id)
            }
            NodeKind::Keyword { auto_resolve } => self.keyword(id, *auto_resolve)?,
            NodeKind::Collection {
                kind: CollectionKind::Vector,
                children,
            } => ExprKind::Vector(
                children
                    .iter()
                    .map(|&child| self.form(child, ExprContext::Value))
                    .collect::<Result<_, _>>()?,
            ),
            NodeKind::Collection {
                kind: CollectionKind::Map,
                children,
            } => {
                self.check_map_keys(children)?;
                ExprKind::Map(
                    children
                        .iter()
                        .map(|&child| self.form(child, ExprContext::Value))
                        .collect::<Result<_, _>>()?,
                )
            }
            NodeKind::Collection {
                kind: CollectionKind::Set,
                children,
            } => {
                self.check_set_members(children, false)?;
                ExprKind::Set(
                    children
                        .iter()
                        .map(|&child| self.form(child, ExprContext::Value))
                        .collect::<Result<_, _>>()?,
                )
            }
            NodeKind::Symbol => {
                self.validate_symbol(id)?;
                let name = self.spelling(id).to_owned();
                self.resolve(id, &name)?
            }
            NodeKind::Prefix {
                kind: PrefixKind::Quote,
                form,
            } => {
                return self.datum(*form, context);
            }
            NodeKind::Collection {
                kind: CollectionKind::List,
                children,
            } => {
                let value = self.list(id, children, context)?;
                return if matches!(self.program.exprs[value.0].kind, ExprKind::Fn { .. }) {
                    self.attach_metadata(id, value, context)
                } else {
                    Ok(value)
                };
            }
            other => {
                let description = match other {
                    NodeKind::Number(NumberKind::BigInteger) => "big integers",
                    NodeKind::Number(NumberKind::Decimal) => "decimal literals",
                    NodeKind::Number(NumberKind::Ratio) => "ratios",
                    NodeKind::Character(_) => "characters",
                    NodeKind::SymbolicValue(_) => "symbolic numbers",
                    NodeKind::Regex => "regular expressions",
                    NodeKind::Collection { .. } => {
                        "collection literals or anonymous reader functions"
                    }
                    NodeKind::Prefix { .. } => "reader prefixes (including quote)",
                    NodeKind::Metadata { .. } => "metadata",
                    NodeKind::Tagged { .. } => "tagged literals",
                    NodeKind::Conditional { .. } => "reader conditionals",
                    NodeKind::NamespacedMap { .. } => "namespaced maps",
                    NodeKind::Argument { .. } => "anonymous reader function arguments",
                    _ => unreachable!(),
                };
                return Err(self.error(id, AnalysisErrorKind::Unsupported(description.into())));
            }
        };
        let value = self.push(kind, node.span.clone(), context);
        if matches!(
            node.kind,
            NodeKind::Collection {
                kind: CollectionKind::Vector | CollectionKind::Map | CollectionKind::Set,
                ..
            }
        ) {
            return self.attach_metadata(id, value, context);
        }
        Ok(value)
    }

    fn list(
        &mut self,
        id: NodeId,
        children: &[NodeId],
        context: ExprContext,
    ) -> Result<ExprId, AnalysisError> {
        let Some((&operator, args)) = children.split_first() else {
            return Ok(self.push(
                ExprKind::List(vec![]),
                self.syntax.nodes[id.0].span.clone(),
                context,
            ));
        };
        if matches!(self.syntax.nodes[operator.0].kind, NodeKind::Nil) {
            return Err(self.error(operator, AnalysisErrorKind::InvalidForm("cannot call nil")));
        }
        if matches!(self.syntax.nodes[operator.0].kind, NodeKind::Keyword { .. })
            && !(1..=2).contains(&args.len())
        {
            return Err(self.error(
                id,
                AnalysisErrorKind::InvalidForm(
                    "literal keyword calls require one or two arguments",
                ),
            ));
        }
        // Binding forms must be recognized before their children are analyzed.
        if matches!(self.syntax.nodes[operator.0].kind, NodeKind::Symbol) {
            self.validate_symbol(operator)?;
            let operator_name = self.spelling(operator).to_owned();
            match operator_name.as_str() {
                "quote" => {
                    if args.len() != 1 {
                        return Err(self.error(
                            id,
                            AnalysisErrorKind::InvalidForm("quote requires one argument"),
                        ));
                    }
                    return self.datum(args[0], context);
                }
                "if" => return self.if_form(id, args, context),
                "do" => {
                    return self.body(
                        args,
                        self.syntax.nodes[id.0].span.clone(),
                        if context == ExprContext::Value && args.len() > 1 {
                            ExprContext::Return
                        } else {
                            context
                        },
                    );
                }
                "let*" => return self.let_form(id, args, context),
                "fn*" => return self.fn_form(id, args, context),
                "def" => return self.def_form(id, args, context),
                "var" => {
                    if args.len() != 1
                        || !matches!(self.syntax.nodes[args[0].0].kind, NodeKind::Symbol)
                    {
                        return Err(self.error(
                            id,
                            AnalysisErrorKind::InvalidForm("var requires one global symbol"),
                        ));
                    }
                    let name = self.spelling(args[0]).to_owned();
                    // Var quote ignores lexical shadows and captures the live global root.
                    let locals = std::mem::take(&mut self.env);
                    let resolved = self.resolve(args[0], &name);
                    self.env = locals;
                    let resolved = resolved?;
                    let mut metadata = None;
                    let (namespace, binding_name) = match &resolved {
                        ExprKind::Global(global) => {
                            let binding = &self.program.globals[global.0];
                            metadata = binding.metadata;
                            (binding.namespace.clone(), binding.name.clone())
                        }
                        ExprKind::CoreFn(_) => {
                            ("cljs.core".into(), name.rsplit('/').next().unwrap().into())
                        }
                        _ => {
                            return Err(self.error(
                                args[0],
                                AnalysisErrorKind::InvalidForm("var requires a global binding"),
                            ));
                        }
                    };
                    let value = self.push(
                        resolved,
                        self.syntax.nodes[args[0].0].span.clone(),
                        ExprContext::Value,
                    );
                    let namespace = self.own_string(namespace.encode_utf16().collect());
                    let name = self.own_string(binding_name.encode_utf16().collect());
                    let symbol = NamedLiteralId(self.program.named_literals.len());
                    self.program.named_literals.push(NamedLiteral {
                        namespace: Some(namespace),
                        name,
                    });
                    return Ok(self.push(
                        ExprKind::Var {
                            value,
                            symbol,
                            metadata,
                        },
                        self.syntax.nodes[id.0].span.clone(),
                        context,
                    ));
                }
                name if name.starts_with('.') && name != "." => {
                    return self.interop(id, name, args, context);
                }
                "ns" | "ns*" | "loop*" | "letfn*" | "recur" | "throw" | "try" | "set!" | "new"
                | "." | "js*" | "deftype*" | "defrecord*" | "case*" | "&" => {
                    return Err(self.error(
                        operator,
                        AnalysisErrorKind::Unsupported(self.spelling(operator).into()),
                    ));
                }
                _ => {}
            }
        }
        // Macro lookup belongs HERE, with the current lexical environment and
        // expression context, before ordinary invocation analysis.
        if let Some(expanded) = self.expand_macro(id, operator, context)? {
            self.macro_depth += 1;
            let result = self.form(expanded, context);
            self.macro_depth -= 1;
            return result.map_err(|error| AnalysisError {
                kind: match error.kind {
                    AnalysisErrorKind::MacroExpansion(_) => error.kind,
                    _ => AnalysisErrorKind::MacroExpansion(format!(
                        "generated by {}: {}",
                        self.spelling(operator),
                        error
                    )),
                },
                span: error.span,
            });
        }
        let callee = self.form(operator, ExprContext::Value)?;
        let args = args
            .iter()
            .map(|&arg| self.form(arg, ExprContext::Value))
            .collect::<Result<_, _>>()?;
        Ok(self.push(
            ExprKind::Call { callee, args },
            self.syntax.nodes[id.0].span.clone(),
            context,
        ))
    }

    fn resolve(&mut self, id: NodeId, name: &str) -> Result<ExprKind, AnalysisError> {
        if matches!(
            name,
            "cljs.core.PersistentQueue.EMPTY" | "cljs.core/PersistentQueue.EMPTY"
        ) {
            return Ok(ExprKind::ReaderLiteral {
                kind: CompilerLiteralKind::Queue,
                items: vec![],
            });
        }
        if let Some(local) = self.lookup(name) {
            return Ok(ExprKind::Local(local));
        }
        if let Some(path) = name.strip_prefix("js/") {
            // Standard ClojureScript resolves js/x to a same-named lexical x.
            if let Some(local) = self.lookup(path) {
                return Ok(ExprKind::Local(local));
            }
            let path: Vec<_> = path.split('.').map(str::to_owned).collect();
            if path.iter().any(|part| !js_identifier(part)) {
                return Err(self.error(
                    id,
                    AnalysisErrorKind::Unsupported(
                        "JavaScript paths require ASCII identifier components".into(),
                    ),
                ));
            }
            let global = self
                .program
                .js_globals
                .iter()
                .position(|global| global.path == path)
                .map(JsGlobalId)
                .unwrap_or_else(|| {
                    let id = JsGlobalId(self.program.js_globals.len());
                    self.program.js_globals.push(JsGlobal { path });
                    id
                });
            return Ok(ExprKind::JsGlobal(global));
        }
        let qualified = (name != "/").then(|| name.split_once('/')).flatten();
        let (namespace, symbol) = if let Some((qualifier, symbol)) = qualified {
            let namespace = self
                .aliases
                .iter()
                .find(|(alias, _)| alias == qualifier)
                .map(|(_, namespace)| namespace.as_str())
                .unwrap_or(qualifier);
            if matches!(namespace, "cljs.core" | "clojure.core") {
                return CoreFnId::resolve(symbol)
                    .map(ExprKind::CoreFn)
                    .ok_or_else(|| {
                        self.error(id, AnalysisErrorKind::UnresolvedSymbol(name.into()))
                    });
            }
            if namespace != self.namespace
                && !self.requires.iter().any(|required| required == namespace)
            {
                return Err(self.error(
                    id,
                    AnalysisErrorKind::UnresolvedSymbol(format!(
                        "{name} (unknown namespace or alias {qualifier})"
                    )),
                ));
            }
            (namespace, symbol)
        } else {
            (self.namespace, name)
        };
        self.globals
            .get(&(namespace.into(), symbol.into()))
            .copied()
            .map(ExprKind::Global)
            .or_else(|| {
                qualified
                    .is_none()
                    .then(|| CoreFnId::resolve(name))
                    .flatten()
                    .map(ExprKind::CoreFn)
            })
            .ok_or_else(|| self.error(id, AnalysisErrorKind::UnresolvedSymbol(name.into())))
    }

    fn keyword(&mut self, id: NodeId, auto_resolve: bool) -> Result<ExprKind, AnalysisError> {
        // Macro-produced names are semantic data. Their spans may cover an
        // entire invocation, so they must never be decoded from that source.
        let (namespace, name) = if let Some(form) =
            self.generated.get(id.0).and_then(Option::as_ref)
            && let ValueView::Keyword(name) = form.data().inspect()
        {
            (name.namespace().map(<[u16]>::to_vec), name.name().to_vec())
        } else {
            let raw = &self.spelling(id)[if auto_resolve { 2 } else { 1 }..];
            let (namespace, name) = if raw == "/" {
                (None, raw)
            } else {
                raw.split_once('/')
                    .map_or((None, raw), |(ns, name)| (Some(ns), name))
            };
            let namespace = if auto_resolve {
                match namespace {
                    None => Some(self.namespace.to_owned()),
                    Some(alias) => Some(
                        self.macro_host
                            .reader_aliases(self.namespace, self.aliases, self.requires)
                            .into_iter()
                            .rev()
                            .find(|(candidate, _)| candidate == alias)
                            .map(|(_, target)| target)
                            .ok_or_else(|| {
                                self.error(
                                    id,
                                    AnalysisErrorKind::UnresolvedSymbol(format!(
                                        "keyword namespace alias {alias}"
                                    )),
                                )
                            })?,
                    ),
                }
            } else {
                namespace.map(str::to_owned)
            };
            (
                namespace.map(|ns| ns.encode_utf16().collect()),
                name.encode_utf16().collect(),
            )
        };
        let namespace = namespace.map(|units| self.own_string(units));
        let name = self.own_string(name);
        let id = NamedLiteralId(self.program.named_literals.len());
        self.program
            .named_literals
            .push(NamedLiteral { namespace, name });
        Ok(ExprKind::Keyword(id))
    }

    fn own_string(&mut self, units: Vec<u16>) -> StringId {
        let id = StringId(self.program.strings.len());
        self.program.strings.push(units);
        id
    }

    fn validate_symbol(&self, id: NodeId) -> Result<(), AnalysisError> {
        if let Some(form) = self.generated.get(id.0).and_then(Option::as_ref)
            && let ValueView::Symbol(name) = form.data().inspect()
            && (String::from_utf16(name.name()).is_err()
                || name
                    .namespace()
                    .is_some_and(|ns| String::from_utf16(ns).is_err()))
        {
            return Err(self.error(
                id,
                AnalysisErrorKind::Unsupported(
                    "non-Unicode executable symbol generated by a macro".into(),
                ),
            ));
        }
        Ok(())
    }

    fn symbol_literal(&mut self, id: NodeId) -> ExprKind {
        let (namespace, name) = if let Some(form) =
            self.generated.get(id.0).and_then(Option::as_ref)
            && let ValueView::Symbol(name) = form.data().inspect()
        {
            (name.namespace().map(<[u16]>::to_vec), name.name().to_vec())
        } else {
            let raw = self.spelling(id);
            let (namespace, name) = if raw == "/" {
                (None, raw)
            } else {
                raw.split_once('/')
                    .map_or((None, raw), |(ns, name)| (Some(ns), name))
            };
            (
                namespace.map(|ns| ns.encode_utf16().collect()),
                name.encode_utf16().collect(),
            )
        };
        let namespace = namespace.map(|ns| self.own_string(ns));
        let name = self.own_string(name);
        let literal = NamedLiteralId(self.program.named_literals.len());
        self.program
            .named_literals
            .push(NamedLiteral { namespace, name });
        ExprKind::Symbol(literal)
    }

    fn check_map_keys(&mut self, children: &[NodeId]) -> Result<(), AnalysisError> {
        let mut seen = std::collections::BTreeSet::new();
        for &key in children.iter().step_by(2) {
            if let Some(data) = self.reader_datum(key)?
                && !seen.insert(data)
            {
                return Err(self.error(key, AnalysisErrorKind::InvalidForm("duplicate map key")));
            }
        }
        Ok(())
    }

    fn check_set_members(
        &mut self,
        children: &[NodeId],
        quoted: bool,
    ) -> Result<(), AnalysisError> {
        let mut seen = std::collections::BTreeSet::new();
        for &member in children {
            // Executable operands must all run, even when identical source forms
            // evaluate equally. Only literal data is rejected before evaluation.
            if !quoted && !self.literal_data(member) {
                continue;
            }
            if let Some(data) = self.reader_datum(member)?
                && !seen.insert(data)
            {
                return Err(self.error(
                    member,
                    AnalysisErrorKind::InvalidForm("duplicate set member"),
                ));
            }
        }
        Ok(())
    }

    fn literal_data(&self, id: NodeId) -> bool {
        match &self.syntax.nodes[id.0].kind {
            NodeKind::Symbol => false,
            NodeKind::Collection {
                kind: CollectionKind::List,
                children,
            } => {
                children.is_empty()
                    || (children.len() == 2
                        && matches!(self.syntax.nodes[children[0].0].kind, NodeKind::Symbol)
                        && self.spelling(children[0]) == "quote")
            }
            NodeKind::Collection { children, .. } => {
                children.iter().all(|&child| self.literal_data(child))
            }
            NodeKind::Prefix {
                kind: PrefixKind::Quote,
                ..
            } => true,
            _ => true,
        }
    }

    // The compiler macro bridge preserves all source children, including equal
    // executable set operands. Validate literal/quoted duplicates here before
    // native set storage deduplicates the macro's ordinary data projection.
    fn check_compiler_sets(&mut self, root: NodeId) -> Result<(), AnalysisError> {
        let mut pending = vec![(root, false)];
        while let Some((id, quoted)) = pending.pop() {
            match self.syntax.nodes[id.0].kind.clone() {
                NodeKind::Collection { kind, children } => {
                    if kind == CollectionKind::Set {
                        self.check_set_members(&children, quoted)?;
                    }
                    let quotes = quoted
                        || (kind == CollectionKind::List
                            && children.len() == 2
                            && matches!(self.syntax.nodes[children[0].0].kind, NodeKind::Symbol)
                            && self.spelling(children[0]) == "quote");
                    pending.extend(children.into_iter().rev().map(|child| (child, quotes)));
                }
                NodeKind::Prefix { kind, form } => pending.push((
                    form,
                    quoted || matches!(kind, PrefixKind::Quote | PrefixKind::SyntaxQuote),
                )),
                NodeKind::Metadata { metadata, target } => {
                    pending.push((target, quoted));
                    pending.push((metadata, true));
                }
                NodeKind::Tagged { tag, form } => {
                    pending.push((form, quoted));
                    pending.push((tag, true));
                }
                NodeKind::Conditional { branches, .. } => pending.push((branches, quoted)),
                NodeKind::NamespacedMap { map, .. } => pending.push((map, quoted)),
                _ => {}
            }
        }
        Ok(())
    }

    // Read identity directly from owned source/Form nodes, without invoking the
    // native interpreter or reconstructing effectful children from map storage.
    fn reader_datum(&mut self, id: NodeId) -> Result<Option<ReaderDatum>, AnalysisError> {
        if self.macro_depth > 0 && self.analysis_depth >= 128 {
            return Err(self.error(
                id,
                AnalysisErrorKind::MacroExpansion(
                    "generated runtime form nesting limit exceeded".into(),
                ),
            ));
        }
        self.analysis_depth += 1;
        let result = self.reader_datum_inner(id);
        self.analysis_depth -= 1;
        result
    }

    fn reader_datum_inner(&mut self, id: NodeId) -> Result<Option<ReaderDatum>, AnalysisError> {
        let node = self.syntax.nodes[id.0].clone();
        if let Some(form) = self.generated.get(id.0).and_then(Option::as_ref)
            && let ValueView::CompilerLiteral(kind) = form.data().inspect()
        {
            let payload = form.data().compiler_literal_data().unwrap();
            return Ok(match (kind, payload.inspect()) {
                (CompilerLiteralKind::BigInteger, ValueView::String(text)) => {
                    Some(ReaderDatum::Number(false, String::from_utf16_lossy(&text)))
                }
                (CompilerLiteralKind::Uuid, ValueView::String(text)) => Some(
                    ReaderDatum::ReaderLiteral(0, String::from_utf16_lossy(&text)),
                ),
                (CompilerLiteralKind::Instant, ValueView::Double(millis)) => {
                    Some(ReaderDatum::ReaderLiteral(1, millis.to_string()))
                }
                _ => None,
            });
        }
        let data = match node.kind {
            NodeKind::Nil => ReaderDatum::Nil,
            NodeKind::Boolean(value) => ReaderDatum::Bool(value),
            NodeKind::Number(kind @ (NumberKind::Integer | NumberKind::Float)) => {
                let Some(value) = self
                    .numbers
                    .get(id.0)
                    .copied()
                    .flatten()
                    .unwrap_or_else(|| number(self.spelling(id), kind))
                else {
                    return Ok(None);
                };
                ReaderDatum::Number(
                    kind == NumberKind::Float,
                    if kind == NumberKind::Integer {
                        if let Some(form) = self.generated.get(id.0).and_then(Option::as_ref) {
                            match form.data().inspect() {
                                ValueView::Integer(n) => n.to_string(),
                                _ => value.to_string(),
                            }
                        } else {
                            crate::reader_literals::integer_key(self.spelling(id))
                        }
                    } else {
                        format!("{:x}", if value == 0.0 { 0 } else { value.to_bits() })
                    },
                )
            }
            NodeKind::String(value) => ReaderDatum::String(value.to_utf16(self.source)),
            NodeKind::Keyword { auto_resolve } => {
                let ExprKind::Keyword(name) = self.keyword(id, auto_resolve)? else {
                    unreachable!()
                };
                self.reader_named(true, name)
            }
            NodeKind::Symbol => {
                let ExprKind::Symbol(name) = self.symbol_literal(id) else {
                    unreachable!()
                };
                self.reader_named(false, name)
            }
            NodeKind::Prefix {
                kind: PrefixKind::Quote,
                form,
            } => {
                let Some(data) = self.reader_datum(form)? else {
                    return Ok(None);
                };
                ReaderDatum::Sequential(vec![
                    ReaderDatum::Named(false, None, "quote".encode_utf16().collect()),
                    data,
                ])
            }
            NodeKind::Collection {
                kind:
                    CollectionKind::List
                    | CollectionKind::Vector
                    | CollectionKind::Map
                    | CollectionKind::Set,
                ref children,
            } => {
                let mut values = Vec::with_capacity(children.len());
                for &child in children {
                    let Some(data) = self.reader_datum(child)? else {
                        return Ok(None);
                    };
                    values.push(data);
                }
                if matches!(
                    node.kind,
                    NodeKind::Collection {
                        kind: CollectionKind::Map,
                        ..
                    }
                ) {
                    let mut pairs = values
                        .as_chunks::<2>()
                        .0
                        .iter()
                        .map(|p| (p[0].clone(), p[1].clone()))
                        .collect::<Vec<_>>();
                    pairs.sort();
                    ReaderDatum::Map(pairs)
                } else if matches!(
                    node.kind,
                    NodeKind::Collection {
                        kind: CollectionKind::Set,
                        ..
                    }
                ) {
                    values.sort();
                    ReaderDatum::Set(values)
                } else {
                    ReaderDatum::Sequential(values)
                }
            }
            _ => return Ok(None),
        };
        Ok(Some(data))
    }

    fn reader_named(&self, keyword: bool, id: NamedLiteralId) -> ReaderDatum {
        let named = &self.program.named_literals[id.0];
        ReaderDatum::Named(
            keyword,
            named.namespace.map(|ns| self.program.strings[ns.0].clone()),
            self.program.strings[named.name.0].clone(),
        )
    }

    /// Quote traverses source/owned macro data directly, without resolution,
    /// macro lookup, printing, reparsing, or constructing an interpreter value.
    fn datum(&mut self, id: NodeId, context: ExprContext) -> Result<ExprId, AnalysisError> {
        if self.macro_depth > 0 && self.analysis_depth >= 128 {
            return Err(self.error(
                id,
                AnalysisErrorKind::MacroExpansion(
                    "generated runtime form nesting limit exceeded".into(),
                ),
            ));
        }
        self.analysis_depth += 1;
        let result = self.datum_inner(id, context);
        self.analysis_depth -= 1;
        result
    }

    fn datum_inner(&mut self, id: NodeId, context: ExprContext) -> Result<ExprId, AnalysisError> {
        let node = self.syntax.nodes[id.0].clone();
        if self.needs_reader(id) {
            let expanded = self.expand_reader(id)?;
            return self.datum(expanded, context);
        }
        if let Some(form) = self.generated.get(id.0).and_then(Option::as_ref).cloned()
            && let ValueView::CompilerLiteral(kind) = form.data().inspect()
        {
            return self.reader_literal(&form, kind, context, true);
        }
        let kind = match node.kind {
            NodeKind::Symbol => self.symbol_literal(id),
            NodeKind::Collection {
                kind:
                    CollectionKind::List
                    | CollectionKind::Vector
                    | CollectionKind::Map
                    | CollectionKind::Set,
                ref children,
            } => {
                if matches!(
                    node.kind,
                    NodeKind::Collection {
                        kind: CollectionKind::Map,
                        ..
                    }
                ) {
                    self.check_map_keys(children)?;
                } else if matches!(
                    node.kind,
                    NodeKind::Collection {
                        kind: CollectionKind::Set,
                        ..
                    }
                ) {
                    self.check_set_members(children, true)?;
                }
                let items = children
                    .iter()
                    .map(|&child| self.datum(child, ExprContext::Value))
                    .collect::<Result<_, _>>()?;
                if matches!(
                    node.kind,
                    NodeKind::Collection {
                        kind: CollectionKind::List,
                        ..
                    }
                ) {
                    ExprKind::List(items)
                } else if matches!(
                    node.kind,
                    NodeKind::Collection {
                        kind: CollectionKind::Map,
                        ..
                    }
                ) {
                    ExprKind::Map(items)
                } else if matches!(
                    node.kind,
                    NodeKind::Collection {
                        kind: CollectionKind::Set,
                        ..
                    }
                ) {
                    ExprKind::Set(items)
                } else {
                    ExprKind::Vector(items)
                }
            }
            NodeKind::Prefix {
                kind: PrefixKind::Quote,
                form,
            } => {
                let name = self.own_string("quote".encode_utf16().collect());
                let literal = NamedLiteralId(self.program.named_literals.len());
                self.program.named_literals.push(NamedLiteral {
                    namespace: None,
                    name,
                });
                let head = self.push(
                    ExprKind::Symbol(literal),
                    node.span.clone(),
                    ExprContext::Value,
                );
                let data = self.datum(form, ExprContext::Value)?;
                ExprKind::List(vec![head, data])
            }
            // Only scalar kinds can use ordinary analysis without resolving or
            // executing anything. Other reader facilities keep their errors.
            _ => return self.form(id, context),
        };
        let value = self.push(kind, node.span, context);
        self.attach_metadata(id, value, context)
    }

    fn def_form(
        &mut self,
        id: NodeId,
        args: &[NodeId],
        context: ExprContext,
    ) -> Result<ExprId, AnalysisError> {
        if !(1..=2).contains(&args.len()) {
            return Err(self.error(
                id,
                AnalysisErrorKind::InvalidForm("def requires a name and optional initializer"),
            ));
        }
        if args.len() == 1 && context == ExprContext::Value {
            return Err(self.error(id, AnalysisErrorKind::Unsupported(
                "uninitialized def in a value position (the reference emits invalid JavaScript)".into())));
        }
        let name = self.binding_name(args[0])?.to_owned();
        let key = (self.namespace.to_owned(), name.clone());
        let global = if let Some(&global) = self.globals.get(&key) {
            global
        } else {
            let global = GlobalId(self.program.globals.len());
            self.program.globals.push(GlobalBinding {
                metadata: None,
                namespace: self.namespace.into(),
                name,
                span: self.syntax.nodes[args[0].0].span.clone(),
                source_index: self.source_index,
            });
            self.globals.insert(key, global);
            global
        };
        if let Some(metadata) = self
            .generated
            .get(args[0].0)
            .and_then(Option::as_ref)
            .and_then(Form::metadata)
        {
            let metadata = self.import_form(&metadata)?;
            self.program.globals[global.0].metadata =
                Some(self.datum(metadata, ExprContext::Value)?);
        }
        // Registration precedes analysis, so self-reference sees stable storage.
        let init = args
            .get(1)
            .map(|&init| self.form(init, ExprContext::Value))
            .transpose()?;
        Ok(self.push(
            ExprKind::Def { global, init },
            self.syntax.nodes[id.0].span.clone(),
            context,
        ))
    }

    fn interop(
        &mut self,
        id: NodeId,
        operator: &str,
        args: &[NodeId],
        context: ExprContext,
    ) -> Result<ExprId, AnalysisError> {
        let (property, field) = operator
            .strip_prefix(".-")
            .map(|name| (name, true))
            .unwrap_or((&operator[1..], false));
        if !js_identifier(property) {
            return Err(self.error(
                id,
                AnalysisErrorKind::Unsupported(
                    "JavaScript members require an ASCII identifier".into(),
                ),
            ));
        }
        if args.is_empty() || (field && args.len() != 1) {
            return Err(self.error(id, AnalysisErrorKind::InvalidForm("property reads require one receiver; method calls require a receiver followed by arguments")));
        }
        if matches!(self.syntax.nodes[args[0].0].kind, NodeKind::Nil) {
            return Err(self.error(
                args[0],
                AnalysisErrorKind::InvalidForm(
                    "JavaScript member access cannot target literal nil",
                ),
            ));
        }
        let receiver = self.form(args[0], ExprContext::Value)?;
        let kind = if field {
            ExprKind::Property {
                receiver,
                property: property.into(),
            }
        } else {
            let args = args[1..]
                .iter()
                .map(|&arg| self.form(arg, ExprContext::Value))
                .collect::<Result<_, _>>()?;
            ExprKind::MethodCall {
                receiver,
                method: property.into(),
                args,
            }
        };
        Ok(self.push(kind, self.syntax.nodes[id.0].span.clone(), context))
    }

    fn expand_macro(
        &mut self,
        call: NodeId,
        operator: NodeId,
        context: ExprContext,
    ) -> Result<Option<NodeId>, AnalysisError> {
        if !matches!(self.syntax.nodes[operator.0].kind, NodeKind::Symbol) {
            return Ok(None);
        }
        let name = self.spelling(operator).to_owned();
        if self.lookup(&name).is_some() {
            return Ok(None);
        }
        let call_span = self.syntax.nodes[call.0].span.clone();
        let error = |message| AnalysisError {
            kind: AnalysisErrorKind::MacroExpansion(format!("while expanding {name}: {message}")),
            span: call_span.clone(),
        };
        let Some(var) = self
            .macro_host
            .resolve(
                self.namespace,
                &name,
                self.globals
                    .contains_key(&(self.namespace.into(), name.clone())),
            )
            .map_err(error)?
        else {
            if name == "defmacro" || name == "cljs.core/defmacro" || name == "clojure.core/defmacro"
            {
                return Err(self.error(operator, AnalysisErrorKind::Unsupported("macro execution (defmacro); define compiler macros in an explicit .clj/.cljc macro namespace".into())));
            }
            return Ok(None);
        };
        if self.macro_depth >= self.macro_host.limits.expansion_depth.min(64) {
            return Err(error(
                "compiler macro expansion depth limit exceeded".into(),
            ));
        }
        self.check_compiler_sets(call)?;
        let _caller = self
            .macro_host
            .bind_namespace(self.namespace)
            .map_err(error)?;
        let reader_aliases =
            self.macro_host
                .reader_aliases(self.namespace, self.aliases, self.requires);
        let locals = self
            .env
            .scopes
            .iter()
            .flat_map(|s| s.iter())
            .map(|id| {
                let (kind, argument) = self.local_kinds.get(id).copied().unwrap_or(("let", None));
                (self.program.locals[id.0].name.clone(), id.0, kind, argument)
            })
            .collect::<Vec<_>>();
        let (line, column) = crate::LineIndex::new(self.source)
            .line_column(self.syntax.nodes[call.0].span.start)
            .unwrap();
        let environment = self
            .macro_host
            .environment(
                self.namespace,
                context,
                &locals,
                self.aliases,
                self.requires,
                (line, column),
            )
            .map_err(error)?;
        let reader_globals = self
            .program
            .globals
            .iter()
            .filter(|g| g.namespace == self.namespace)
            .map(|g| g.name.clone())
            .collect::<Vec<_>>();
        let form = if let Some(form) = self.generated.get(call.0).and_then(Option::as_ref) {
            form.clone()
        } else {
            let c = self.macro_host.context_mut();
            let source = self
                .macro_source
                .get_or_insert_with(|| c.source(self.namespace, self.source));
            let form = c.lower_compiler_form(
                source,
                &self.syntax,
                call,
                &reader_aliases,
                &self.discards,
                &reader_globals,
            );
            form.map_err(|e| error(e.to_string()))?
        };
        let expanded = self
            .macro_host
            .expand(&form, &var, &environment)
            .map_err(error)?;
        self.import_form(&expanded)
            .map(Some)
            .map_err(|failure| AnalysisError {
                kind: AnalysisErrorKind::MacroExpansion(format!("generated by {name}: {failure}")),
                span: failure.span,
            })
    }

    fn needs_reader(&self, root: NodeId) -> bool {
        if self
            .generated
            .get(root.0)
            .and_then(Option::as_ref)
            .is_some()
        {
            return false;
        }
        let span = &self.syntax.nodes[root.0].span;
        if self.discards[self.next_discard..]
            .iter()
            .any(|id| span.contains(&self.syntax.nodes[id.0].span.start))
        {
            return true;
        }
        let mut pending = vec![root];
        while let Some(id) = pending.pop() {
            match &self.syntax.nodes[id.0].kind {
                NodeKind::Regex
                | NodeKind::Tagged { .. }
                | NodeKind::Metadata { .. }
                | NodeKind::NamespacedMap { .. }
                | NodeKind::Collection {
                    kind: CollectionKind::AnonymousFn,
                    ..
                }
                | NodeKind::Prefix {
                    kind:
                        PrefixKind::SyntaxQuote
                        | PrefixKind::Deref
                        | PrefixKind::VarQuote
                        | PrefixKind::Unquote
                        | PrefixKind::UnquoteSplicing,
                    ..
                } => return true,
                NodeKind::Collection { children, .. } => pending.extend(children),
                NodeKind::Prefix { form, .. } => pending.push(*form),
                _ => (),
            }
        }
        false
    }

    fn read_discards_before(&mut self, end: usize) -> Result<(), AnalysisError> {
        while let Some(&id) = self.discards.get(self.next_discard) {
            if self.syntax.nodes[id.0].span.start >= end {
                break;
            }
            self.next_discard += 1;
            self.expand_reader(id)?;
        }
        Ok(())
    }

    fn expand_reader(&mut self, id: NodeId) -> Result<NodeId, AnalysisError> {
        self.check_compiler_sets(id)?;
        let _caller = self
            .macro_host
            .bind_namespace(self.namespace)
            .map_err(|e| self.error(id, AnalysisErrorKind::MacroExpansion(e)))?;
        let aliases = self
            .macro_host
            .reader_aliases(self.namespace, self.aliases, self.requires);
        let reader_globals = self
            .program
            .globals
            .iter()
            .filter(|g| g.namespace == self.namespace)
            .map(|g| g.name.clone())
            .collect::<Vec<_>>();
        let c = self.macro_host.context_mut();
        let source = self
            .macro_source
            .get_or_insert_with(|| c.source(self.namespace, self.source));
        let form = c
            .lower_compiler_form(
                source,
                &self.syntax,
                id,
                &aliases,
                &self.discards,
                &reader_globals,
            )
            .map_err(|e| AnalysisError {
                span: e.span.bytes(),
                kind: AnalysisErrorKind::MacroExpansion(format!("reader: {e}")),
            })?;
        while self.discards.get(self.next_discard).is_some_and(|discard| {
            self.syntax.nodes[discard.0].span.start < self.syntax.nodes[id.0].span.end
        }) {
            self.next_discard += 1;
        }
        self.import_form(&form)
    }

    fn attach_metadata(
        &mut self,
        id: NodeId,
        value: ExprId,
        context: ExprContext,
    ) -> Result<ExprId, AnalysisError> {
        let metadata = self
            .generated
            .get(id.0)
            .and_then(Option::as_ref)
            .and_then(Form::metadata);
        if let Some(metadata) = metadata {
            let metadata = self.import_form(&metadata)?;
            let metadata = self.datum(metadata, ExprContext::Value)?;
            return Ok(self.push(
                ExprKind::WithMeta { value, metadata },
                self.syntax.nodes[id.0].span.clone(),
                context,
            ));
        }
        Ok(value)
    }

    fn reader_literal(
        &mut self,
        form: &Form,
        kind: CompilerLiteralKind,
        context: ExprContext,
        quoted: bool,
    ) -> Result<ExprId, AnalysisError> {
        let data = form
            .data()
            .compiler_literal_data()
            .expect("compiler literal payload");
        if kind == CompilerLiteralKind::BigInteger {
            let ValueView::String(text) = data.inspect() else {
                unreachable!("integer payload")
            };
            let value = String::from_utf16_lossy(&text)
                .parse::<f64>()
                .expect("validated integer");
            return Ok(self.push(ExprKind::Number(value), form.span().bytes(), context));
        }
        let payload = if let Some(payload) = form.node().compiler_payload.and_then(|id| form.at(id))
        {
            payload
        } else {
            self.macro_host
                .context_mut()
                .form_from_data(&data, &form.span())
                .map_err(|e| AnalysisError {
                    kind: AnalysisErrorKind::MacroExpansion(e.to_string()),
                    span: form.span().bytes(),
                })?
        };
        let payload = self.import_form(&payload)?;
        let mut items = Vec::new();
        if matches!(
            kind,
            CompilerLiteralKind::JsArray
                | CompilerLiteralKind::JsObject
                | CompilerLiteralKind::Queue
        ) {
            let NodeKind::Collection { children, .. } = self.syntax.nodes[payload.0].kind.clone()
            else {
                unreachable!()
            };
            for (index, child) in children.into_iter().enumerate() {
                if kind == CompilerLiteralKind::JsObject && index % 2 == 0 {
                    let string = match self.generated[child.0].as_ref().unwrap().data().inspect() {
                        ValueView::Keyword(name) => name.name().to_vec(),
                        ValueView::String(text) => text.to_vec(),
                        _ => unreachable!("validated JS key"),
                    };
                    let string = self.own_string(string);
                    items.push(self.push(
                        ExprKind::String(string),
                        form.span().bytes(),
                        ExprContext::Value,
                    ));
                } else {
                    items.push(if quoted {
                        self.datum(child, ExprContext::Value)?
                    } else {
                        self.form(child, ExprContext::Value)?
                    });
                }
            }
        } else {
            items.push(self.datum(payload, ExprContext::Value)?);
        }
        Ok(self.push(
            ExprKind::ReaderLiteral { kind, items },
            form.span().bytes(),
            context,
        ))
    }

    /// Append semantic data directly to a private syntax arena. Spellings are
    /// owned side-table data, never printed/reparsed or sliced from fake source.
    fn import_form(&mut self, form: &Form) -> Result<NodeId, AnalysisError> {
        let mut spelling = None;
        let mut numeric = None;
        let unsupported = |what| AnalysisError {
            kind: AnalysisErrorKind::Unsupported(what),
            span: form.span().bytes(),
        };
        let kind = match &form.node().kind {
            FormKind::Collection { kind, .. } => {
                let children = form
                    .children()
                    .iter()
                    .map(|child| self.import_form(child))
                    .collect::<Result<_, _>>()?;
                NodeKind::Collection {
                    kind: *kind,
                    children,
                }
            }
            FormKind::Scalar => match form.data().inspect() {
                ValueView::Nil => NodeKind::Nil,
                ValueView::Boolean(value) => NodeKind::Boolean(value),
                ValueView::Integer(value) => {
                    numeric = Some(Some(value as f64));
                    NodeKind::Number(NumberKind::Integer)
                }
                ValueView::Double(value) => {
                    numeric = Some(Some(value));
                    NodeKind::Number(NumberKind::Float)
                }
                ValueView::Keyword(_) => NodeKind::Keyword {
                    auto_resolve: false,
                },
                ValueView::Ratio {
                    numerator,
                    denominator,
                } => {
                    if denominator != 1 {
                        return Err(unsupported(
                            "non-integral ratios are not ClojureScript constants".into(),
                        ));
                    }
                    numeric = Some(Some(numerator as f64));
                    NodeKind::Number(NumberKind::Integer)
                }
                ValueView::CompilerLiteral(_) => NodeKind::Regex,
                ValueView::Character(value) => {
                    NodeKind::String(crate::StringValue::Decoded(vec![value]))
                }
                ValueView::String(value) => {
                    NodeKind::String(crate::StringValue::Decoded(value.to_vec()))
                }
                ValueView::Symbol(name) => {
                    // Invalid Unicode is legal quoted name data. Delay the
                    // executable-name check until analysis knows its context.
                    spelling = Some(
                        String::from_utf16(name.name())
                            .and_then(|local| match name.namespace() {
                                Some(ns) => String::from_utf16(ns)
                                    .map(|namespace| format!("{namespace}/{local}")),
                                None => Ok(local),
                            })
                            .unwrap_or_default(),
                    );
                    NodeKind::Symbol
                }
                other => {
                    return Err(unsupported(format!(
                        "runtime value generated by a macro: {other:?}"
                    )));
                }
            },
        };
        let id = NodeId(self.syntax.nodes.len());
        self.syntax.to_mut().nodes.push(crate::Node {
            kind,
            span: form.span().bytes(),
        });
        self.generated.resize(id.0, None);
        self.spellings.resize(id.0, None);
        self.numbers.resize(id.0, None);
        self.generated.push(Some(form.clone()));
        self.spellings.push(spelling);
        self.numbers.push(numeric);
        Ok(id)
    }

    fn body(
        &mut self,
        forms: &[NodeId],
        span: Span,
        context: ExprContext,
    ) -> Result<ExprId, AnalysisError> {
        let mut exprs = Vec::with_capacity(forms.len());
        for (index, &form) in forms.iter().enumerate() {
            exprs.push(self.form(
                form,
                if index + 1 == forms.len() {
                    context
                } else {
                    ExprContext::Discard
                },
            )?);
        }
        Ok(self.push(ExprKind::Do(exprs), span, context))
    }

    fn if_form(
        &mut self,
        id: NodeId,
        args: &[NodeId],
        context: ExprContext,
    ) -> Result<ExprId, AnalysisError> {
        if !(2..=3).contains(&args.len()) {
            return Err(self.error(
                id,
                AnalysisErrorKind::InvalidForm(
                    "if requires a test, a then branch, and an optional else branch",
                ),
            ));
        }
        let test = self.form(args[0], ExprContext::Value)?;
        let yes = self.form(args[1], context)?;
        let no = if let Some(&no) = args.get(2) {
            self.form(no, context)?
        } else {
            self.push(ExprKind::Nil, self.syntax.nodes[id.0].span.clone(), context)
        };
        Ok(self.push(
            ExprKind::If { test, yes, no },
            self.syntax.nodes[id.0].span.clone(),
            context,
        ))
    }

    fn vector(&self, id: NodeId, message: &'static str) -> Result<&[NodeId], AnalysisError> {
        match &self.syntax.nodes[id.0].kind {
            NodeKind::Collection {
                kind: CollectionKind::Vector,
                children,
            } => Ok(children),
            _ => Err(self.error(id, AnalysisErrorKind::InvalidForm(message))),
        }
    }

    fn let_form(
        &mut self,
        id: NodeId,
        args: &[NodeId],
        context: ExprContext,
    ) -> Result<ExprId, AnalysisError> {
        let Some((&bindings, body)) = args.split_first() else {
            return Err(self.error(
                id,
                AnalysisErrorKind::InvalidForm("let* requires a binding vector"),
            ));
        };
        let pairs = self
            .vector(bindings, "let* requires a binding vector")?
            .to_vec();
        if !pairs.len().is_multiple_of(2) {
            return Err(self.error(
                bindings,
                AnalysisErrorKind::InvalidForm("let* requires an even number of binding forms"),
            ));
        }
        self.env.scopes.push(Vec::new());
        let result = (|| {
            let mut bindings = Vec::with_capacity(pairs.len() / 2);
            for pair in pairs.as_chunks::<2>().0 {
                self.binding_name(pair[0])?;
                // Own initializer sees outer bindings, but never its new binding.
                let init = self.form(pair[1], ExprContext::Value)?;
                let local = self.bind(pair[0])?;
                bindings.push((local, init));
            }
            let span = self.syntax.nodes[id.0].span.clone();
            let body = self.body(
                body,
                span.clone(),
                if context == ExprContext::Value {
                    ExprContext::Return
                } else {
                    context
                },
            )?;
            Ok(self.push(ExprKind::Let { bindings, body }, span, context))
        })();
        self.env.scopes.pop();
        result
    }

    fn fn_form(
        &mut self,
        id: NodeId,
        args: &[NodeId],
        context: ExprContext,
    ) -> Result<ExprId, AnalysisError> {
        let (name, args) = match args.split_first() {
            Some((&name, rest)) if matches!(self.syntax.nodes[name.0].kind, NodeKind::Symbol) => {
                (Some(name), rest)
            }
            _ => (None, args),
        };
        // Accept both (fn* [x] ...) and the single-method (fn* ([x] ...)).
        let args = match args.first().map(|id| &self.syntax.nodes[id.0].kind) {
            Some(NodeKind::Collection {
                kind: CollectionKind::List,
                children,
            }) => {
                if args.len() != 1 {
                    for &method in args {
                        let NodeKind::Collection {
                            kind: CollectionKind::List,
                            children,
                        } = &self.syntax.nodes[method.0].kind
                        else {
                            return Err(self.error(
                                method,
                                AnalysisErrorKind::InvalidForm(
                                    "fn* arities must be lists beginning with a parameter vector",
                                ),
                            ));
                        };
                        let Some(&params) = children.first() else {
                            return Err(self.error(
                                method,
                                AnalysisErrorKind::InvalidForm("fn* requires a parameter vector"),
                            ));
                        };
                        self.vector(params, "fn* requires a parameter vector")?;
                    }
                    return Err(self.error(
                        id,
                        AnalysisErrorKind::Unsupported("multiple function arities".into()),
                    ));
                }
                children.clone()
            }
            _ => args.to_vec(),
        };
        let Some((&params, body)) = args.split_first() else {
            return Err(self.error(
                id,
                AnalysisErrorKind::InvalidForm("fn* requires a parameter vector"),
            ));
        };
        let parameters = self
            .vector(params, "fn* requires a parameter vector")?
            .to_vec();
        self.env.scopes.push(Vec::new());
        let result = (|| {
            let name = name.map(|name| self.bind(name)).transpose()?;
            if let Some(name) = name {
                self.local_kinds.insert(name, ("fn", None));
            }
            let mut params: Vec<LocalId> = Vec::with_capacity(parameters.len());
            let mut rest = None;
            let mut parameters = parameters.into_iter();
            while let Some(parameter) = parameters.next() {
                if self.spelling(parameter) == "&" {
                    let parameter = parameters.next().ok_or_else(|| {
                        self.error(
                            parameter,
                            AnalysisErrorKind::InvalidForm("& requires one rest binding"),
                        )
                    })?;
                    if parameters.next().is_some() {
                        return Err(self.error(
                            parameter,
                            AnalysisErrorKind::InvalidForm("rest binding must be last"),
                        ));
                    }
                    rest = Some(self.bind(parameter)?);
                    break;
                }
                let spelling = self.binding_name(parameter)?;
                if params
                    .iter()
                    .any(|id| self.program.locals[id.0].name == spelling)
                {
                    return Err(self.error(
                        parameter,
                        AnalysisErrorKind::DuplicateParameter(spelling.into()),
                    ));
                }
                let local = self.bind(parameter)?;
                self.local_kinds.insert(local, ("arg", Some(params.len())));
                params.push(local);
            }
            let span = self.syntax.nodes[id.0].span.clone();
            let body = self.body(body, span.clone(), ExprContext::Return)?;
            Ok(self.push(
                ExprKind::Fn {
                    name,
                    params,
                    rest,
                    body,
                },
                span,
                context,
            ))
        })();
        self.env.scopes.pop();
        result
    }
}

pub(crate) fn number(text: &str, kind: NumberKind) -> Option<f64> {
    if kind == NumberKind::Float || kind == NumberKind::Decimal {
        return text.trim_end_matches('M').parse::<f64>().ok();
    }
    if kind == NumberKind::Ratio {
        let (n, d) = text.split_once('/')?;
        return crate::reader_literals::integral_ratio(n, d);
    }
    let text = if kind == NumberKind::BigInteger {
        text.strip_suffix('N')?
    } else {
        text
    };
    let unsigned = text.strip_prefix(['+', '-']).unwrap_or(text);
    let (radix, digits) = if let Some(hex) = unsigned
        .strip_prefix("0x")
        .or_else(|| unsigned.strip_prefix("0X"))
    {
        (16, hex)
    } else if let Some((base, digits)) = unsigned.split_once(['r', 'R']) {
        (base.parse().ok()?, digits)
    } else if unsigned.starts_with('0') {
        (8, unsigned)
    } else {
        (10, unsigned)
    };
    // Decimal parsing supplies correct IEEE rounding even above native integer widths.
    let magnitude = if radix == 10 {
        digits.parse::<f64>().ok()?
    } else if let Ok(n) = u128::from_str_radix(digits, radix) {
        n as f64
    } else {
        digits.chars().try_fold(0.0, |n, d| {
            Some(n * radix as f64 + d.to_digit(radix)? as f64)
        })?
    };
    Some(if text.starts_with('-') && magnitude != 0.0 {
        -magnitude
    } else {
        magnitude
    })
}

fn js_identifier(name: &str) -> bool {
    let mut bytes = name.bytes();
    matches!(bytes.next(), Some(b'a'..=b'z' | b'A'..=b'Z' | b'_' | b'$'))
        && bytes.all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'_' | b'$'))
}
