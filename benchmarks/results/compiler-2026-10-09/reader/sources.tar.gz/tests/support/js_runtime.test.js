"use strict";

// Independent expected-value checks for the first-party runtime. No compiler
// lowering or observation encoder participates in these assertions.
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const runtime = (0, eval)(fs.readFileSync(path.join(__dirname, "../../src/js_runtime.js"), "utf8"));
const c = runtime.core;
const throwsError = thunk => assert.throws(thunk, error => error.constructor === Error);
const v = runtime.vector(10, 20, 30);
const kw = runtime.keyword("demo", "x");

assert.deepEqual(runtime.inspect(kw), {kind: "keyword", namespace: "demo", name: "x", spelling: "demo/x"});
assert.deepEqual(runtime.inspect(v), {kind: "vector", items: [10, 20, 30]});
assert.equal(c.name(kw), "x");
assert.equal(c.namespace(kw), "demo");
assert.equal(c.keyword(kw), kw);
assert.deepEqual(runtime.inspect(c.keyword(null, "x")), {kind: "keyword", namespace: null, name: "x", spelling: "x"});
assert.equal(c.namespace(c.keyword(undefined, "x")), undefined);
assert.equal(c.equal(c.keyword(null, "x"), c.keyword("x")), true);
assert.equal(c.equal(kw, c.keyword("demo/x"), c.keyword("demo", "x")), true);
assert.equal(c.equal(kw, "demo/x"), false);
assert.equal(c.equal(c.keyword("a/b/c"), c.keyword(null, "a/b/c")), true);
assert.equal(c.name(c.keyword("a/b/c")), "a");
assert.equal(c.namespace(c.keyword("a/b/c")), null);
assert.equal(runtime.inspect(c.keyword("a/b/c")).spelling, "a/b/c");
assert.equal(c.equal(c.keyword("a/b/c"), c.keyword("a")), false);
assert.equal(c.name(c.keyword("/")), "/");
assert.equal(c.namespace(c.keyword("/")), null);
assert.equal(c.namespace(c.keyword("/x")), "");
assert.equal(c.name(c.keyword("ns/")), "");
assert.equal(c.namespace(c.keyword(c.keyword("other/ns"), "x")), "ns");
assert.equal(c.name(c.keyword("ns", c.keyword("other/x"))), "x");
for (const value of [null, undefined, 1, false, {}, []]) assert.equal(c.keyword(value), null);
for (const args of [[], ["a", "x", "extra"]]) throwsError(() => c.keyword(...args));
for (const args of [[1, "x"], ["ns", null]]) throwsError(() => c.keyword(...args));
assert.equal(c.name("a/b"), "a/b");
for (const value of [null, undefined, 1, false, v, {}]) throwsError(() => c.name(value));
for (const value of [null, undefined, "x", 1, false, v]) throwsError(() => c.namespace(value));
assert.equal(c.name(kw, "ignored"), "x");
assert.equal(c.namespace(kw, "ignored"), "demo");

assert.equal(c.count(), 0);
assert.equal(c.count(null), 0);
assert.equal(c.count(v, "ignored"), 3);
assert.equal(c.count(runtime.vector()), 0);
const originalItems = [1, 2];
const copiedVector = runtime.vectorFromArray(originalItems);
originalItems[0] = 99;
originalItems.push(3);
assert.equal(Object.isFrozen(originalItems), false);
assert.deepEqual(runtime.inspect(copiedVector).items, [1, 2]);
const largeVector = runtime.vectorFromArray(Array.from({length: 150000}, (_, i) => i));
assert.equal(c.count(largeVector), 150000);
assert.equal(c.nth(largeVector, 149999), 149999);
assert.equal(c.count("\ud800\udc00"), 2);
assert.equal(c.count([]), 0);
assert.equal(c.count([1, 2]), 2);
for (const value of [false, 1, kw, {}]) throwsError(() => c.count(value));
for (const [index, expected] of [[0, 10], [-0, 10], [0.9, 10], [1.8, 20], [2.9, 30]]) {
  assert.equal(c.nth(v, index), expected);
  assert.equal(c.get(v, index), expected);
  assert.equal(v.call(null, index, "ignored"), expected);
  assert.equal(c.contains(v, index), Number.isInteger(index));
}
for (const index of [-1, -0.9, 3, Infinity, -Infinity, NaN]) {
  throwsError(() => c.nth(v, index));
  throwsError(() => v.call(null, index));
  assert.equal(c.nth(v, index, "missing"), "missing");
  assert.equal(c.get(v, index, "missing"), "missing");
  assert.equal(c.contains(v, index), false);
}
for (const index of ["0", "1.8", "", true, false, null, undefined, kw]) {
  throwsError(() => c.nth(v, index));
  throwsError(() => c.nth(null, index));
  throwsError(() => c.nth(null, index, "missing"));
  throwsError(() => v.call(null, index));
  assert.equal(c.get(v, index, "missing"), "missing");
  assert.equal(c.contains(v, index), false);
}
assert.equal(c.nth(null, 0), null);
assert.equal(c.nth(undefined, 0), undefined);
assert.equal(c.nth(null, NaN), null);
assert.equal(c.nth(null, 0, "missing"), "missing");
assert.equal(c.nth(null, 0, null), null);
assert.equal(c.nth(v, 9, null), null);
assert.equal(c.get(v, 9, null), null);
for (const f of [c.get, c.nth]) {
  for (const args of [[], [v], [v, 0, "missing", "extra"]]) throwsError(() => f(...args));
}
throwsError(() => v.call(null));
assert.equal(c.contains(), false);
assert.equal(c.contains(v), false);
assert.equal(c.get(null, 0), null);
assert.equal(c.get(undefined, 0, false), false);
assert.equal(c.get(runtime.vector(null, false, undefined), 0, "missing"), null);
assert.equal(c.get(runtime.vector(null, false, undefined), 1, "missing"), false);
assert.equal(c.get(runtime.vector(null, false, undefined), 2, "missing"), undefined);

for (const [index, expected] of [[0, "a"], [-0.9, "a"], [1.8, "b"], ["0", "a"], ["1.8", "b"], ["", "a"], [false, "a"], [true, "b"]]) {
  assert.equal(c.get("abc", index, "missing"), expected);
  assert.equal(c.contains("abc", index), true);
  if (typeof index === "number") assert.equal(c.nth("abc", index), expected);
  else throwsError(() => c.nth("abc", index));
}
for (const index of [-1, 3, null, undefined, NaN, kw, runtime.vector()]) {
  assert.equal(c.get("abc", index, "missing"), "missing");
  assert.equal(c.contains("abc", index), false);
}
assert.equal(c.nth("\ud800", 0), "\ud800");
assert.equal(c.name(c.keyword("\ud800")), "\ud800");
assert.equal(c.namespace(c.keyword("\ud800", "\udfff")), "\ud800");
assert.equal(c.get("abc", 3, undefined), undefined);
throwsError(() => c.nth("abc", 3));
assert.equal(c.nth("abc", 3, "missing"), "missing");
assert.equal(kw.call(null, v), null);
assert.equal(kw.call(null, v, "missing"), "missing");
assert.equal(kw.call(null, v, null), null);
throwsError(() => kw.call(null));
throwsError(() => kw.call(null, v, null, "extra"));

assert.equal(c.equal(), true);
assert.equal(c.equal(NaN), true);
assert.equal(c.equal(NaN, NaN), false);
assert.equal(c.equal(-0, 0), true);
assert.equal(c.equal(null, undefined), true);
assert.equal(c.equal(runtime.vector(), null), false);
assert.equal(c.equal(runtime.vector(), []), false);
assert.equal(c.equal(runtime.vector(kw, runtime.vector(null)), runtime.vector(c.keyword("demo/x"), runtime.vector(undefined))), true);
assert.equal(c.equal(runtime.vector(1, 2), runtime.vector(1)), false);
assert.equal(c.equal(runtime.vector(1), runtime.vector(2)), false);
assert.equal(c.equal(runtime.vector(NaN), runtime.vector(NaN)), false);
const nanVector = runtime.vector(NaN);
assert.equal(c.equal(nanVector, nanVector), true);
const host = {kind: "keyword", namespace: "demo", name: "x"};
assert.equal(c.equal(host, host), true);
assert.equal(c.equal(host, {...host}), false);
assert.equal(c.equal(kw, host), false);
assert.equal(c.equal(runtime.vector(host), runtime.vector(host)), true);
assert.equal(runtime.inspect(host), null);
assert.equal(runtime.inspect([10, 20, 30]), null);
assert.equal(runtime.inspect(Object.create(Object.getPrototypeOf(kw))), null);
assert.equal(runtime.inspect(Object.create(Object.getPrototypeOf(v))), null);
assert.equal(c.get([10], 0, "missing"), "missing");
assert.equal(c.get({0: 10}, 0, "missing"), "missing");
throwsError(() => c.nth([10], 0));
throwsError(() => c.nth({}, 0, "missing"));

for (const value of [kw, v, Object.getPrototypeOf(kw), Object.getPrototypeOf(v), runtime, c, runtime.inspect(v), runtime.inspect(v).items]) {
  assert.equal(Object.isFrozen(value), true);
}
assert.throws(() => { kw.name = "changed"; }, TypeError);
assert.throws(() => { Object.getPrototypeOf(v).call = () => 99; }, TypeError);
assert.throws(() => { runtime.inspect(v).items[0] = 99; }, TypeError);
assert.equal(c.nth(v, 0), 10);
assert.equal(c.name(kw), "x");
assert.equal(Object.isFrozen(host), false);
assert.equal(Object.isFrozen(runtime.inspect(runtime.vector(host)).items[0]), false);
console.log("bounded JavaScript runtime assertions passed");

// Lists own only immutable cells and share their tails; seq views retain a
// frozen snapshot and advance offsets without copying the remaining elements.
const oneList = c.list(1, 2, 3);
assert.equal(c.rest(c.conj(oneList, 0)), oneList);
assert.equal(c.seq(oneList), oneList);
assert.equal(c.conj(oneList), oneList);
assert.equal(c.next(c.rest(c.rest(oneList))), null);
const empty = c.list();
assert.equal(c.rest(empty), empty);
assert.equal(c.rest(null), empty);
assert.equal(c.seq(empty), null);
assert.equal(c.first(empty), null);
assert.equal(c.next(empty), null);
assert.deepEqual(runtime.inspect(c.conj(null, 1, 2)), {kind: 'list', items: [2, 1]});
assert.deepEqual(runtime.inspect(c.conj(c.seq(v), 0)), {kind: 'seq', items: [0, 10, 20, 30]});
const sourceVector = c.vector(1, 2), sourceSeq = c.seq(sourceVector);
assert.equal(c.rest(c.conj(sourceSeq, 0)), sourceSeq);
assert.deepEqual(runtime.inspect(c.assoc(sourceVector, 0, 9, 2, 3)).items, [9, 2, 3]);
assert.deepEqual(runtime.inspect(sourceVector).items, [1, 2]);
assert.deepEqual(runtime.inspect(sourceSeq).items, [1, 2]);
throwsError(() => c.assoc(sourceVector, 0, 8, 99, 4));
assert.deepEqual(runtime.inspect(sourceVector).items, [1, 2]);
assert.deepEqual(runtime.inspect(c.assoc(sourceVector, .5, 9, 2)).items, [9, 2, null]);
assert.deepEqual(runtime.inspect(c.assoc(sourceVector, 0)).items, [undefined, 2]);
for (const key of [-1, -.5, 3, NaN, Infinity, '0', null]) throwsError(() => c.assoc(sourceVector, key, 9));
for (const values of [[], [1, 2], [kw, c.vector(1)], [null, undefined, false]]) {
  const valuesByKind = [c.vector(...values), c.list(...values)];
  if (values.length) valuesByKind.push(c.seq(c.vector(...values)));
  for (const a of valuesByKind) for (const b of valuesByKind) {
    assert.equal(c.equal(a, b), true);
    assert.equal(runtime.hash(a), runtime.hash(b));
  }
}
assert.equal(runtime.hash(null), runtime.hash(undefined));
assert.equal(runtime.hash(0), runtime.hash(-0));
const hostFunction = () => 1;
assert.equal(runtime.hash(host), runtime.hash(host));
assert.equal(runtime.hash(hostFunction), runtime.hash(hostFunction));
assert.notEqual(runtime.hash(host), runtime.hash({...host}));
assert.equal(c.equal(c.list(NaN), c.vector(NaN)), false);
assert.equal(c.equal(c.list(), null), false);
assert.equal(c.equal(c.seq('ab'), c.list('a', 'b')), true);
const sx = c.symbol('a', 'x');
assert.equal(c.symbol(sx), sx);
assert.equal(c.equal(sx, c.symbol('a/x')), true);
assert.equal(c.equal(sx, c.keyword('a/x')), false);
assert.equal(runtime.hash(sx), runtime.hash(c.symbol('a/x')));
assert.equal(c.name(sx), 'x');
assert.equal(c.namespace(sx), 'a');
assert.equal(sx.call(null, oneList, false), false);
for (const args of [[null], [1], [false], [], ['a','x',1]]) throwsError(() => c.symbol(...args));
assert.equal(c.name(c.symbol('/x')), '/x');
assert.equal(c.namespace(c.symbol('/x')), null);
assert.equal(c.name(c.symbol('a/b/c')), 'b/c');
assert.equal(c.name(c.keyword(c.symbol('a/b/c'))), 'b/c');
assert.equal(c.name(c.symbol(c.keyword('a/b/c'))), 'b/c');
assert.equal(c.namespace(c.symbol(undefined, 'x')), undefined);
assert.equal(c.name(c.symbol('\ud800')), '\ud800');
throwsError(() => sx.call(null));
throwsError(() => sx.call(null, null, 1, 2));
assert.equal(sx.call(null, null), null);
for (const value of [oneList, sourceSeq, c.conj(sourceSeq, 0), empty, sx]) {
  assert.equal(Object.isFrozen(value), true);
  assert.equal(Object.isFrozen(Object.getPrototypeOf(value)), true);
  assert.equal(runtime.inspect(Object.create(Object.getPrototypeOf(value))), null);
  const observation = runtime.inspect(value);
  assert.equal(Object.isFrozen(observation), true);
  if (observation.items) assert.equal(Object.isFrozen(observation.items), true);
  if (observation.kind !== 'symbol') {
    assert.equal(value.call, undefined);
    assert.equal(c.get(value, 0, 'missing'), 'missing');
    assert.equal(c.contains(value, 0), false);
  }
}
const ownedListArray = [1, 2];
const ownedList = runtime.listFromArray(ownedListArray);
ownedListArray[0] = 9;
assert.deepEqual(runtime.inspect(ownedList).items, [1, 2]);
assert.equal(Object.isFrozen(ownedListArray), false);
for (const current of [oneList, empty]) {
  for (const i of [-1, -.5, .5, Infinity, NaN, 99]) {
    assert.equal(c.nth(current, i, 'missing'), 'missing');
    throwsError(() => c.nth(current, i));
  }
}
assert.equal(c.nth(c.seq(sourceVector), .5, 'missing'), undefined);
assert.equal(c.nth(c.rest(sourceVector), -1), 1);
assert.equal(c.nth(c.seq('ab'), .5, 'missing'), undefined);
assert.equal(c.nth(c.rest('ab'), -1), 'a');
assert.equal(c.nth(c.seq(largeVector), .5, 'missing'), 'missing');
assert.equal(c.nth(c.conj(c.seq(sourceVector), 0), 1.5, 'missing'), undefined);
assert.deepEqual(runtime.inspect(c.seq('\ud83d\ude00')).items, ['\ud83d', '\ude00']);
// 100,000 cells/views would expose repeated tail copying as quadratic work.
const longItems = Array.from({length: 100000}, (_, i) => i);
const longList = runtime.listFromArray(longItems);
const longVector = runtime.vectorFromArray(longItems);
for (const collection of [longList, longVector]) {
  let traversed = 0;
  for (let current = c.seq(collection); current !== null; current = c.next(current)) {
    assert.equal(c.first(current), traversed++);
    assert.equal(c.count(current), 100001 - traversed);
  }
  assert.equal(traversed, 100000);
}
assert.equal(c.nth(longList, 99999), 99999);
assert.equal(c.equal(longList, longVector), true);
assert.equal(runtime.hash(longList), runtime.hash(longVector));
console.log('symbol, list, sequence and update assertions passed');

// Immutable structural-key maps: keys, values and hashes cannot be replaced
// through escaped wrappers, entry observations or callable prototypes.
const k = c.keyword('k'), nested = c.vector(c.list(1, 2));
const m0 = c.hashMap(k, nested, c.vector(1, 2), 'pair', '__proto__', false, null, undefined);
assert.equal(c.get(m0, c.list(1, 2)), 'pair');
assert.equal(c.get(m0, c.seq(c.vector(1, 2))), 'pair');
assert.equal(c.get(m0, '__proto__', 'missing'), false);
assert.equal(c.get(m0, undefined, 'missing'), undefined);
assert.equal(c.contains(m0, undefined), true);
assert.equal(c.get(m0, 'absent', 'missing'), 'missing');
assert.equal(c.contains(m0, 'absent'), false);
assert.equal(k.call(null, m0), nested);
assert.equal(m0.call(null, k), nested);
assert.equal(m0.call(null, 'absent', false), false);
throwsError(() => m0.call(null));
throwsError(() => m0.call(null, k, null, false));
const m1 = c.assoc(m0, k, c.conj(nested, 3), c.list(1, 2), 'changed', 'new');
const m2 = c.dissoc(m1, k, c.seq(c.vector(1, 2)), null);
assert.equal(c.get(m0, k), nested);
assert.equal(c.get(m0, c.vector(1, 2)), 'pair');
assert.equal(c.get(m1, c.vector(1, 2)), 'changed');
assert.equal(c.get(m1, 'new', 'missing'), null);
assert.equal(c.count(m0), 4);
assert.equal(c.count(m1), 5);
assert.equal(c.count(m2), 2);
assert.equal(c.dissoc(m0), m0);
assert.equal(c.dissoc(null, k), null);
assert.equal(c.dissoc(undefined, k), undefined);
assert.equal(c.conj(m0, null), m0);
const originalKey = runtime.inspect(m0).entries[1][0];
assert.equal(runtime.inspect(m1).entries[1][0], originalKey);
assert.equal(c.first(c.get(m0, k)), c.first(c.get(m1, k)));
assert.equal(c.equal(c.assoc(null, k, 1), c.hashMap(k, 1)), true);
const reverse = c.hashMap(null, undefined, '__proto__', false, c.list(1, 2), 'pair', c.keyword('k'), c.vector(c.vector(1, 2)));
assert.equal(c.equal(m0, reverse), true);
assert.equal(runtime.hash(m0), runtime.hash(reverse));
assert.equal(c.get(c.hashMap(m0, 99), reverse), 99);
assert.equal(c.equal(c.hashMap(k, null), c.hashMap(k, undefined)), true);
assert.equal(c.equal(c.hashMap(k, null), c.hashMap('different', null)), false);
assert.equal(c.equal(c.hashMap(), c.vector()), false);
assert.equal(c.equal(c.hashMap(k, 1), c.hashMap(k, 2)), false);
assert.equal(c.equal(c.hashMap(k, 1), c.hashMap()), false);
const distinctNames = c.hashMap('k', 1, k, 2, c.symbol('k'), 3);
assert.equal(c.count(distinctNames), 3);
assert.equal(c.symbol('k').call(null, distinctNames), 3);
const foreign1 = {}, foreign2 = {}, foreignMap = c.hashMap(foreign1, 1, foreign2, 2, hostFunction, 3);
foreign1.value = 'changed';
assert.equal(c.get(foreignMap, foreign1), 1);
assert.equal(c.get(foreignMap, foreign2), 2);
assert.equal(c.get(foreignMap, hostFunction), 3);
assert.equal(c.get(foreignMap, {}), null);
assert.equal(Object.isFrozen(foreign1), false);
// Actual polynomial-hash collisions, including nested sequential/map keys.
assert.equal(runtime.hash('Aa'), runtime.hash('BB'));
for (const [a, b] of [['Aa', 'BB'], [c.vector('Aa'), c.list('BB')], [c.hashMap('Aa', 1), c.hashMap('BB', 1)]]) {
  assert.equal(runtime.hash(a), runtime.hash(b));
  assert.equal(c.equal(a, b), false);
  const collision = c.hashMap(a, 'a', b, 'b');
  assert.equal(c.count(collision), 2);
  assert.equal(c.get(collision, a), 'a');
  assert.equal(c.get(collision, b), 'b');
  assert.equal(c.get(c.assoc(collision, a, 'new'), b), 'b');
  assert.equal(c.get(c.dissoc(collision, a), b), 'b');
}
assert.equal(c.seq(c.hashMap()), null);
assert.equal(c.rest(c.hashMap()), empty);
assert.equal(c.next(c.hashMap()), null);
assert.equal(c.count(c.seq(m0)), c.count(m0));
for (let current = c.seq(m0); current !== null; current = c.next(current)) {
  const entry = c.first(current);
  assert.equal(runtime.inspect(entry).kind, 'vector');
  assert.equal(c.count(entry), 2);
  assert.equal(c.get(m0, c.nth(entry, 0)), c.nth(entry, 1));
}
for (const member of [c.vector(), c.vector(k), c.list(k, 1), c.list(c.vector(k, 1), 99), false, 1, 'x']) {
  throwsError(() => c.conj(m0, member));
  assert.equal(c.count(m0), 4);
  assert.equal(c.get(m0, k), nested);
}
assert.equal(c.equal(c.conj(c.hashMap(), c.vector(k, 1, 2)), c.hashMap(k, 1)), true);
assert.equal(c.equal(c.conj(c.hashMap(), c.list(c.vector(k, 1))), c.hashMap(k, 1)), true);
assert.equal(c.equal(c.conj(c.hashMap(), c.seq(c.vector(c.vector(k, 1)))), c.hashMap(k, 1)), true);
assert.equal(c.equal(c.conj(c.hashMap(), m0), m0), true);
for (const args of [[k], [k, 1, 'odd']]) throwsError(() => c.hashMap(...args));
for (const value of [v, oneList, false, 1, {}]) throwsError(() => c.dissoc(value, k));
const suppliedPairs = [k, nested];
const copiedMap = runtime.mapFromArray(suppliedPairs);
suppliedPairs[1] = 99;
assert.equal(Object.isFrozen(suppliedPairs), false);
assert.equal(c.get(copiedMap, k), nested);
const mapObservation = runtime.inspect(m0);
for (const value of [m0, Object.getPrototypeOf(m0), mapObservation, mapObservation.entries, ...mapObservation.entries])
  assert.equal(Object.isFrozen(value), true);
assert.throws(() => { mapObservation.entries[0][1] = 99; }, TypeError);
assert.throws(() => { mapObservation.entries.push([1, 2]); }, TypeError);
assert.throws(() => { Object.getPrototypeOf(m0).call = () => 99; }, TypeError);
assert.throws(() => { m0.hash = 0; }, TypeError);
assert.equal(c.get(c.hashMap(m0, 9), reverse), 9);
assert.equal(runtime.inspect(Object.create(Object.getPrototypeOf(m0))), null);
// Retain every version across repeated replacements and deletions.
const retained = [c.hashMap(k, 0)];
for (let i = 1; i <= 512; i++) retained.push(c.assoc(retained.at(-1), k, i, i, nested));
for (let i = 0; i < retained.length; i++) {
  assert.equal(c.get(retained[i], k), i);
  assert.equal(c.count(retained[i]), i + 1);
}
console.log('structural map, collision, sharing and mutation assertions passed');

assert.equal(c.dissoc(), null);
const undefinedKeyMap = c.hashMap(undefined, 1);
assert.equal(runtime.inspect(c.assoc(undefinedKeyMap, null, 2)).entries[0][0], undefined);
assert.equal(c.get(undefinedKeyMap, null), 1);

// Set membership uses structural hashes/equality and retains the first member.
const setVector = c.vector(1, 2), setList = c.list(1, 2);
const s0 = c.hashSet(setVector, setList, null, false, c.hashMap(k, nested));
assert.equal(c.count(s0), 4);
assert.equal(c.get(s0, setList), setVector);
assert.equal(s0.call(null, setList), setVector);
assert.equal(c.get(s0, undefined, 'missing'), null);
assert.equal(c.get(s0, false, 'missing'), false);
assert.equal(s0.call(null, false, 'missing'), false);
assert.equal(c.contains(s0, undefined), true);
assert.equal(c.contains(s0, false), true);
assert.equal(c.contains(s0, 'missing'), false);
assert.equal(s0.call(null, 123), null);
assert.equal(s0.call(null, 123, false), false);
throwsError(() => s0.call(null));
throwsError(() => s0.call(null, 1, 2, 3));
const s1 = c.conj(s0, setList, 9, 9), s2 = c.disj(s1, c.list(1, 2), null, 123);
assert.equal(c.count(s0), 4);
assert.equal(c.count(s1), 5);
assert.equal(c.count(s2), 3);
assert.equal(c.get(s1, setList), setVector);
assert.equal(c.contains(s2, setVector), false);
assert.equal(c.get(s0, c.hashMap(k, c.list(c.vector(1, 2)))) , runtime.inspect(s0).items[3]);
assert.equal(c.get(s1, runtime.inspect(s0).items[3]), runtime.inspect(s0).items[3]);
assert.equal(c.disj(s0), s0);
assert.equal(c.disj(123), 123);
assert.equal(c.disj(null, 1), null);
assert.equal(c.disj(undefined), undefined);
assert.equal(c.disj(undefined, 1), null);
assert.equal(c.disj(), null);
assert.equal(c.equal(c.disj(s0, 'missing'), s0), true);
const reverseSet = c.hashSet(c.hashMap(k, c.list(c.vector(1, 2))), false, undefined, setList);
assert.equal(c.equal(s0, reverseSet), true);
assert.equal(runtime.hash(s0), runtime.hash(reverseSet));
assert.equal(c.get(c.hashMap(s0, 'set key'), reverseSet), 'set key');
assert.equal(c.get(c.hashSet(s0), reverseSet), s0);
assert.equal(c.equal(c.hashSet(1), c.hashSet(2)), false);
assert.equal(c.equal(c.hashSet(1), c.hashSet(1, 2)), false);
for (const x of [c.vector(1), c.list(1), c.hashMap(1, 1), new Set([1]), [1]]) {
  assert.equal(c.equal(c.hashSet(1), x), false);
  assert.equal(c.equal(x, c.hashSet(1)), false);
}
for (const [a, b] of [['Aa', 'BB'], [c.vector('Aa'), c.list('BB')], [c.hashSet('Aa'), c.hashSet('BB')]]) {
  assert.equal(runtime.hash(a), runtime.hash(b));
  const collision = c.hashSet(a, b);
  assert.equal(c.count(collision), 2);
  assert.equal(c.get(collision, a), a);
  assert.equal(c.get(collision, b), b);
  assert.equal(c.get(c.disj(collision, a), b), b);
  assert.equal(c.contains(c.disj(collision, a), a), false);
}
const inputMembers = [setVector, false], copiedSet = runtime.setFromArray(inputMembers);
inputMembers[0] = 99; inputMembers.push(9);
assert.equal(Object.isFrozen(inputMembers), false);
assert.equal(c.get(copiedSet, setList), setVector);
assert.equal(c.count(copiedSet), 2);
const setObservation = runtime.inspect(s0);
for (const value of [s0, Object.getPrototypeOf(s0), setObservation, setObservation.items])
  assert.equal(Object.isFrozen(value), true);
assert.throws(() => {setObservation.items[0] = 99;}, TypeError);
assert.throws(() => {setObservation.items.push(9);}, TypeError);
assert.throws(() => {Object.getPrototypeOf(s0).call = () => 99;}, TypeError);
assert.throws(() => {s0.hash = 0;}, TypeError);
assert.equal(runtime.inspect(Object.create(Object.getPrototypeOf(s0))), null);
const hostSet = new Set([1]), hostMember = {value: 1}, identitySet = c.hashSet(hostSet, hostMember, hostFunction);
hostSet.add(2); hostMember.value = 2;
assert.equal(c.count(identitySet), 3);
assert.equal(c.get(identitySet, hostSet), hostSet);
assert.equal(c.contains(identitySet, {value: 2}), false);
assert.equal(c.contains(identitySet, hostFunction), true);
assert.equal(Object.isFrozen(hostSet), false);
assert.equal(Object.isFrozen(hostMember), false);
assert.equal(runtime.inspect(hostSet), null);
assert.equal(c.get(hostSet, 1, 'missing'), 'missing');
for (const x of [hostSet, c.vector(), c.hashMap(), 1, false]) throwsError(() => c.disj(x, 1));
assert.equal(c.seq(c.hashSet()), null);
assert.equal(c.first(c.hashSet()), null);
assert.equal(c.rest(c.hashSet()), empty);
assert.equal(c.next(c.hashSet()), null);
assert.equal(runtime.inspect(c.seq(s0)).kind, 'seq');
let seenSet = c.hashSet(), setVisits = 0;
for (let current = c.seq(s0); current !== null; current = c.next(current)) {
  assert.equal(c.count(current), c.count(s0) - setVisits);
  assert.equal(c.contains(s0, c.first(current)), true);
  assert.equal(c.contains(seenSet, c.first(current)), false);
  seenSet = c.conj(seenSet, c.first(current)); setVisits++;
}
assert.equal(setVisits, c.count(s0));
assert.equal(c.equal(seenSet, s0), true);
const setVersions = [c.hashSet(nested)];
for (let i = 0; i < 512; i++) setVersions.push(c.conj(setVersions.at(-1), i));
for (let i = 0; i < setVersions.length; i++) {
  assert.equal(c.count(setVersions[i]), i + 1);
  assert.equal(c.get(setVersions[i], nested), nested);
  assert.equal(c.contains(setVersions[i], i), false);
  assert.equal(c.count(c.disj(setVersions[i], nested)), i);
}
const undefinedSet = c.hashSet(undefined, null);
assert.equal(c.count(undefinedSet), 1);
assert.equal(c.get(undefinedSet, null, 'missing'), undefined);
assert.equal(c.contains(undefinedSet, null), true);
assert.equal(runtime.inspect(undefinedSet).items[0], undefined);
assert.equal(runtime.hash(c.hashSet(-0)), runtime.hash(c.hashSet(0)));
assert.equal(c.equal(c.hashSet(NaN), c.hashSet(NaN)), false);
const nanSet = c.hashSet(NaN);
assert.equal(c.equal(nanSet, nanSet), true);
console.log('structural set, collision, representative, sharing and mutation assertions passed');

assert.equal(c.count(runtime.setFromArray(Array(150000).fill(nested))), 1);

// Finite reductions use the ordinary call method afresh at each step and never
// invoke a completion arity. Empty/singleton paths preserve marker identity.
const marker = c.reduced(v), nestedMarker = c.reduced(marker);
assert.equal(c.isReduced(marker), true);
assert.equal(c.isReduced(Object.create(Object.getPrototypeOf(marker))), false);
assert.equal(c.isReduced({val: v}), false);
assert.equal(c.deref(marker), v);
assert.equal(c.deref(nestedMarker), marker);
assert.equal(c.unreduced(nestedMarker), marker);
assert.equal(c.unreduced(v), v);
assert.deepEqual(runtime.inspect(marker), {kind: 'opaque'});
for (const value of [marker, Object.getPrototypeOf(marker)]) assert.equal(Object.isFrozen(value), true);
assert.equal(c.equal(c.reduced(1), c.reduced(1)), false);
assert.equal(c.equal(marker, marker), true);
assert.equal(c.deref(c.reduced(host)), host);
assert.equal(Object.isFrozen(host), false);
assert.throws(() => {marker.val = 9;}, TypeError);
for (const value of [null, undefined, 0, {}, c.vector(), c.list()]) throwsError(() => c.deref(value));
for (const collection of [null, undefined, c.vector(), c.list(), c.hashMap(), c.hashSet(), '', c.seq(c.vector())]) {
  assert.equal(c.reduce(null, marker, collection), marker);
  assert.equal(c.reduce(function() {assert.equal(arguments.length, 0); return marker;}, collection), marker);
}
for (const collection of [c.vector(marker), c.list(marker), c.hashSet(marker), c.seq(c.vector(marker))]) {
  assert.equal(c.reduce(null, collection), marker);
  const result = c.reduce((acc, item) => c.reduced(c.reduced(item)), 0, collection);
  assert.equal(c.isReduced(result), true);
  assert.equal(c.deref(result), marker);
}
const callTrace = [];
const reducer = {
  get call() {
    callTrace.push('get');
    return function(self, a, b) {
      assert.equal(this, reducer);
      assert.equal(self, null);
      assert.equal(arguments.length, 3);
      callTrace.push([a,b]);
      return a+b;
    };
  }
};
assert.equal(c.reduce(reducer, 0, c.vector(1,2,3)), 6);
assert.deepEqual(callTrace, ['get',[0,1],'get',[1,2],'get',[3,3]]);
let steps = 0;
const thrown = {exact: 'thrown identity'};
const changingReducer = {get call() {
  if (steps) throw thrown;
  return (_self,a,b) => {steps++; return a+b;};
}};
assert.throws(() => c.reduce(changingReducer, 0, c.vector(1,2,3)), e => e === thrown);
assert.equal(steps, 1);
for (const collection of [c.vector(1,2,3), c.list(1,2,3), c.seq(c.vector(1,2,3)), c.conj(c.seq(c.vector(2,3)),1), c.hashSet(1,2,3)]) {
  let seen = 0;
  assert.equal(c.reduce(function(a,b) {assert.equal(arguments.length,2); seen++; return a+b;}, 0, collection), 6);
  assert.equal(seen,3);
  seen=0;
  assert.equal(c.reduce(function(a,b) {assert.equal(arguments.length,2); seen++; return c.reduced(a+b);}, 0, collection), c.first(collection));
  assert.equal(seen,1);
}
assert.equal(c.reduce(c.add, largeVector), 11249925000);
assert.equal(c.reduce(c.add, 0, largeVector), 11249925000);
const largeList = runtime.listFromArray(Array.from({length: 150000}, (_, i) => i));
assert.equal(c.reduce(c.add, largeList), 11249925000);
assert.equal(c.reduce(c.add, 0, c.seq(largeVector)), 11249925000);
assert.equal(c.reduce((a,b) => a + b.length, 0, 'x'.repeat(150000)), 150000);
assert.equal(c.reduce(c.add, 'a\ud800\udc00'), 'a\ud800\udc00');
assert.equal(c.reduce(null, 'x'), 'x');
assert.deepEqual(runtime.inspect(c.reduce(null, c.hashMap(kw, 7))).items, [kw, 7]);
assert.equal(c.equal(c.reduce(c.conj, c.hashMap(), c.hashMap(kw, 7)), c.hashMap(kw, 7)), true);
for (const args of [[], [c.add], [c.add,0,c.vector(),9]]) throwsError(() => c.reduce(...args));
for (const value of [false, 1, kw, {}, marker]) throwsError(() => c.reduce(c.add,0,value));
assert.equal(c.add(),0);
assert.equal(c.add(marker),marker);
assert.equal(c.add(undefined),undefined);
assert.equal(c.add(1,2,3,4),10);
assert.equal(c.add(9007199254740991,1,1),9007199254740992);
assert.equal(Object.is(c.add(-0),-0),true);
assert.equal(Object.is(c.add(-0,-0),-0),true);
assert.equal(c.add(1e308,1e308),Infinity);
assert.equal(Number.isNaN(c.add(NaN,1)),true);
console.log('finite reduction assertions passed');
