#!/usr/bin/env python3
"""Executable assertion inventory; no dependencies and no language implementation.

The committed inventory is source evidence, never a passing result. Only this
invocation's complete compiler + checked release/checkout observations can cover
an assertion. Parser acceptance and native execution have independent columns.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
REVISION = "a5e94c988fd0b50ffcff1ce6add12ffbb7839a3e"
RELEASE = "1.12.134"
LAYERS = ("lexer", "parser", "native", "javascript", "release", "checkout")
SEMANTIC_LAYERS = ("javascript", "release", "checkout")


def jsonl(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def unique(rows, key, label):
    result = {}
    for row in rows:
        identity = row[key]
        if identity in result:
            raise ValueError(f"duplicate {label}: {identity}")
        result[identity] = row
    return result


def fixtures():
    result = []
    path = ROOT / "tests/fixtures/compiler-language.tsv"
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line or line.startswith("#"):
            continue
        identity, source, outcome, trace, stdout, native = line.split("\t")
        result.append({
            "id": identity, "source": source,
            "expected": {"id": identity, "outcome": json.loads(outcome),
                         "trace": json.loads(trace), "stdout": json.loads(stdout)},
            "native_stdout": None if native == "-" else json.loads(native),
        })
    return unique(result, "id", "fixture")


def load_contract():
    manifest = json.loads((HERE / "manifest.json").read_text(encoding="utf-8"))
    if manifest["revision"] != REVISION:
        raise ValueError("inventory has a different source revision")
    for filename, field in (("inventory.jsonl", "inventory_sha256"), ("bodies.jsonl", "bodies_sha256"),
                            ("extract_inventory.py", "extractor_sha256")):
        if hashlib.sha256((HERE / filename).read_bytes()).hexdigest() != manifest[field]:
            raise ValueError(f"inventory drift: {filename}; regenerate and review source dispositions")
    inventory = unique(jsonl(HERE / "inventory.jsonl"), "id", "assertion")
    bodies = unique(jsonl(HERE / "bodies.jsonl"), "id", "body")
    cases = fixtures()
    witnesses = unique(jsonl(HERE / "witnesses.jsonl"), "assertion_id", "witness")
    if not inventory or not bodies or not cases:
        raise ValueError("empty inventory, body catalog, or fixture set")
    if len(inventory) != manifest["counts"]["assertions"] or len(bodies) != manifest["counts"]["bodies"]:
        raise ValueError("inventory count drift")
    body_assertions = []
    for body in bodies.values():
        span = body["source_span"]
        if hashlib.sha256(span["text"].encode()).hexdigest() != span["sha256"]:
            raise ValueError(f"changed complete test body: {body['id']}")
        body_assertions.extend(body["assertions"])
    if len(body_assertions) != len(set(body_assertions)) or set(body_assertions) != set(inventory):
        raise ValueError("omitted or duplicated body assertions")
    for identity, row in inventory.items():
        if row["body_id"] not in bodies:
            raise ValueError(f"unknown complete body for {identity}")
        if row["disposition"] not in ("in-scope", "unrelated"):
            raise ValueError(f"invalid disposition for {identity}")
        if not row["feature"] or not row["reason"]:
            raise ValueError(f"missing feature or rationale for {identity}")
        assertion = row["assertion"]
        if hashlib.sha256(assertion["text"].encode()).hexdigest() != assertion["sha256"]:
            raise ValueError(f"changed assertion text for {identity}")
        body = bodies[row["body_id"]]
        span = body["source_span"]
        offset = assertion["start_byte"] - span["start_byte"]
        length = assertion["end_byte"] - assertion["start_byte"]
        if (row["body_sha256"] != span["sha256"] or row["source"] != body["source"]
                or body["source_span"]["text"].encode()[offset:offset + length] != assertion["text"].encode()
                or identity not in body["assertions"]):
            raise ValueError(f"assertion detached from original complete body: {identity}")
    linked_cases = set()
    reference_contracts = {}
    for identity, witness in witnesses.items():
        row = inventory.get(identity)
        if row is None or row["disposition"] != "in-scope":
            raise ValueError(f"witness must reference an in-scope assertion: {identity}")
        if witness["assertion_sha256"] != row["assertion"]["sha256"]:
            raise ValueError(f"stale assertion witness: {identity}")
        if witness["fixture_id"] not in cases or not witness["rationale"].strip():
            raise ValueError(f"missing witness fixture or adaptation rationale: {identity}")
        linked_cases.add(witness["fixture_id"])
        # A difference is a verified pair of versioned expectations, never an
        # expected compiler failure or a shortcut around the release oracle.
        difference = witness.get("version_difference")
        if difference:
            if not difference.get("reason") or same_json(difference.get("release"), difference.get("checkout")):
                raise ValueError(f"unsubstantiated version difference: {identity}")
            for kind in ("release", "checkout"):
                if not isinstance(difference.get(kind), dict):
                    raise ValueError(f"missing {kind} expected outcome: {identity}")
            if not same_json(difference["checkout"], cases[witness["fixture_id"]]["expected"]):
                raise ValueError(f"checkout must remain the fixture contract: {identity}")
        contract = {kind: difference[kind] if difference else cases[witness["fixture_id"]]["expected"]
                    for kind in ("release", "checkout")}
        previous = reference_contracts.setdefault(witness["fixture_id"], contract)
        if not same_json(previous, contract):
            raise ValueError(f"inconsistent reference expectations for shared fixture: {witness['fixture_id']}")
    if linked_cases != set(cases):
        raise ValueError(f"unmapped fixtures: {sorted(set(cases) - linked_cases)}")
    return inventory, witnesses, cases


def result(status, detail="", **extra):
    return {"status": status, **({"detail": detail} if detail else {}), **extra}


def invoke(command, directory, *, source="", timeout=30, cwd=ROOT):
    """File-backed output retains crashes and hangs without pipe descendants.

    Kill the owned process group on POSIX; never kill by executable name.
    """
    directory.mkdir(parents=True, exist_ok=True)
    (directory / "invocation.json").write_text(json.dumps([str(arg) for arg in command]), encoding="utf-8")
    (directory / "stdin").write_bytes(source.encode("utf-8"))
    started = time.monotonic()
    with (directory / "stdin").open("rb") as stdin, \
            (directory / "stdout").open("wb") as stdout, \
            (directory / "stderr").open("wb") as stderr:
        try:
            process = subprocess.Popen(command, cwd=cwd, stdin=stdin, stdout=stdout,
                                       stderr=stderr, start_new_session=os.name == "posix")
        except OSError as error:
            return result("unavailable", str(error))
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            if os.name == "posix":
                os.killpg(process.pid, signal.SIGKILL)
            else:
                process.kill()
            process.wait()
            return result("timed-out", f"exceeded {timeout}s; artifacts: {directory}")
    try:
        output = (directory / "stdout").read_bytes().decode("utf-8")
    except UnicodeDecodeError:
        return result("invalid-output", f"stdout is not UTF-8; artifacts: {directory}")
    return result("completed" if code == 0 else "failed", returncode=code,
                  stdout=output,
                  stderr=(directory / "stderr").read_bytes().decode("utf-8", errors="replace"),
                  elapsed_seconds=round(time.monotonic() - started, 3))


def observations(output, expected):
    """Require exactly one ordered complete outcome for each expected ID."""
    def object_fields(pairs):
        fields = {}
        for key, value in pairs:
            if key in fields:
                raise ValueError(f"duplicate JSON field: {key}")
            fields[key] = value
        return fields

    def invalid_number(value):
        raise ValueError(f"non-JSON numeric value: {value}")

    try:
        lines = [json.loads(line, object_pairs_hook=object_fields, parse_constant=invalid_number)
                 for line in output.splitlines()]
        if [line.get("id") for line in lines] != [case["id"] for case in expected]:
            raise ValueError("missing, duplicate, reordered, or extra outcome")
        if any(set(line) != {"id", "outcome", "trace", "stdout"} for line in lines):
            raise ValueError("incomplete outcome protocol")
    except (ValueError, AttributeError, TypeError) as error:
        return {case["id"]: result("invalid-output", str(error)) for case in expected}
    return {case["id"]: result("passed" if same_json(line, case["expected"]) else "mismatch",
                              observed=line)
            for case, line in zip(expected, lines)}


def same_json(left, right):
    # Python considers True == 1, whereas the JavaScript outcome contract does
    # not. JSON numbers share a representation, but booleans never do.
    if isinstance(left, bool) != isinstance(right, bool):
        return False
    if isinstance(left, dict) and isinstance(right, dict):
        return left.keys() == right.keys() and all(same_json(left[key], right[key]) for key in left)
    if isinstance(left, list) and isinstance(right, list):
        return len(left) == len(right) and all(same_json(a, b) for a, b in zip(left, right))
    if type(left) is not type(right) and not (type(left) in (int, float) and type(right) in (int, float)):
        return False
    return left == right


def local_layers(case, binary, directory, timeout):
    layers = {}
    for layer, flags in (("lexer", []), ("parser", ["--parse"]), ("native", ["--eval"])):
        if layer == "native" and case["native_stdout"] is None:
            layers[layer] = result("not-applicable", "no native expectation; compiler-only host behavior")
            continue
        run = invoke([binary, *flags, "-"], directory / layer, source=case["source"], timeout=timeout)
        if run["status"] == "completed":
            if layer == "native":
                status = "passed" if run["stdout"] == case["native_stdout"] else "mismatch"
            else:
                status = "accepted"
            layers[layer] = result(status, observed=run["stdout"] if layer == "native" else None)
        else:
            layers[layer] = result("rejected" if run["status"] == "failed" else run["status"],
                                   run.get("detail", run.get("stderr", "")))
    compiled = invoke([binary, "--compile", "-"], directory / "compile",
                      source=f"(fn* [observe] {case['source']})", timeout=timeout)
    if compiled["status"] != "completed":
        layers["javascript"] = result("rejected" if compiled["status"] == "failed" else compiled["status"],
                                      compiled.get("detail", compiled.get("stderr", "")))
        return layers
    # Same test-only lexical runtime adapter as tests/execution.rs; production
    # JavaScript has no global brand or inspection API.
    javascript = compiled["stdout"].replace(
        "\n  const rt = ", "\n  const rt = globalThis.lightRuntime = ", 1)
    script = ("globalThis.lightInspectValue = value => globalThis.lightRuntime?.inspect(value) ?? null;\n"
              f"globalThis.lightCases = [{javascript}];\n"
              f"globalThis.lightCaseMetadata = {json.dumps([[case['id'], case['source']]])};\n"
              + (ROOT / "tests/support/execution.js").read_text(encoding="utf-8"))
    ran = invoke([os.environ.get("NODE", "node"), "-"], directory / "javascript", source=script,
                 timeout=timeout)
    layers["javascript"] = (observations(ran["stdout"], [case])[case["id"]]
                            if ran["status"] == "completed" else ran)
    return layers


def reference_cases(cases, kind, checkout, directory, timeout):
    directory.mkdir(parents=True, exist_ok=True)
    input_path = directory / "cases.tsv"
    input_path.write_text("".join(f"{case['id']}\t{case['source']}\n" for case in cases), encoding="utf-8")
    identity = RELEASE if kind == "release" else REVISION
    dependency = (f'{{:mvn/version "{RELEASE}"}}' if kind == "release"
                  else "{:local/root " + json.dumps(str(checkout)) + "}")
    command = [os.environ.get("CLOJURE", "clojure"), "-Srepro", "-Sdeps",
               "{:paths [] :deps {org.clojure/clojurescript " + dependency + "}}",
               "-M", "tests/reference/execution.clj", kind, identity,
               "-" if kind == "release" else str(checkout), str(directory), "cases", str(input_path)]
    compiled = invoke(command, directory / "build", timeout=timeout)
    if compiled["status"] != "completed":
        status = "reference-unavailable" if compiled["status"] == "unavailable" else compiled["status"]
        failure = result(status, compiled.get("detail", compiled.get("stderr", "")))
        return {case["id"]: failure for case in cases}
    settings = "REFERENCE SETTINGS {:optimizations :none, :static-fns false, :def-emits-var false}"
    if (f"REFERENCE IDENTITY {kind} {identity}" not in compiled["stdout"]
            or settings not in compiled["stdout"] or not (directory / "reference.js").is_file()):
        return {case["id"]: result("invalid-reference", "unverified identity/options or missing output")
                for case in cases}
    script = (f"process.chdir({json.dumps(str(directory))});\n"
              f"require({json.dumps(str(directory / 'reference.js'))});\n"
              + (ROOT / "tests/support/execution.js").read_text(encoding="utf-8"))
    ran = invoke([os.environ.get("NODE", "node"), "-"], directory / "node", source=script, timeout=timeout)
    if ran["status"] != "completed":
        return {case["id"]: ran for case in cases}
    return {identity: {**observation, "reference_identity": kind + " " + (RELEASE if kind == "release" else REVISION),
                       "settings": {"optimizations": "none", "static-fns": False, "def-emits-var": False}}
            for identity, observation in observations(ran["stdout"], cases).items()}


def classify(row, witness, evidence):
    if row["disposition"] == "unrelated":
        return "unrelated", row["reason"]
    if witness is None:
        return "missing", "no assertion-faithful executable witness"
    observed = evidence.get(witness["fixture_id"], {})
    for layer in SEMANTIC_LAYERS:
        status = observed.get(layer, {}).get("status", "not-run")
        if status != "passed":
            return "missing", f"{layer}: {status}"
    if witness.get("version_difference"):
        return "version-difference", witness["version_difference"]["reason"]
    return "covered", "generated JavaScript and both pinned references match the assertion witness"


def boundary_inventory():
    """Keep former accepted-source restrictions separate from negative tests."""
    rows = []
    for line in (ROOT / "tests/fixtures/analysis-boundaries.tsv").read_text(encoding="utf-8").splitlines():
        if not line or line.startswith("#"):
            continue
        identity, mode, before, rejected, after, category, diagnostic, release, checkout = line.split("\t")
        if category == "accepted":
            disposition = "accepted-boundary"
        elif release in ("accepted", "warning") or checkout in ("accepted", "warning"):
            disposition = "missing-capability"
        else:
            disposition = "negative-test"
        if identity in ("ns-package", "ns-import", "special-nsstar"):
            disposition = "unrelated-build-loading"
        feature = ("functions-apply" if identity.startswith("fn-") else
                   "recursion" if identity in ("special-loopstar", "special-letfnstar", "special-recur") else
                   "exceptions" if identity in ("special-throw", "special-try") else
                   "reader-metadata" if identity.startswith("reader-") else
                   "namespaces" if identity.startswith("ns-") else "language-boundaries")
        rows.append({"id": identity, "feature": feature, "disposition": disposition,
                     "source": before + rejected + after, "mode": mode,
                     "local_category": category, "diagnostic": diagnostic,
                     "release": release, "checkout": checkout})
    return rows


def assemble(inventory, witnesses, evidence, *, features=(), identities=()):
    rows = []
    for identity, row in inventory.items():
        if features and row["feature"] not in features:
            continue
        if identities and identity not in identities:
            continue
        witness = witnesses.get(identity)
        status, reason = classify(row, witness, evidence)
        rows.append({"id": identity, "feature": row["feature"], "status": status,
                     "reason": reason, "source": row["source"], "test": row["test"],
                     "line": row["assertion"]["start_line"], "fixture_id": witness["fixture_id"] if witness else None,
                     "layers": evidence.get(witness["fixture_id"], {}) if witness else {}})
    if not rows:
        raise ValueError("selection contains no assertions")
    counts = Counter(row["status"] for row in rows)
    sections = defaultdict(Counter)
    for row in rows:
        sections[row["feature"]][row["status"]] += 1
    boundary_rows = boundary_inventory()
    return {"schema_version": 1, "upstream_revision": REVISION, "release": RELEASE,
            "scope": "assertions in the 11 inventoried source files; not the upstream suite",
            "selection": {"features": list(features), "ids": list(identities)},
            "counts": {key: counts[key] for key in ("covered", "missing", "version-difference", "unrelated")},
            "features": {key: dict(value) for key, value in sorted(sections.items())},
            "boundary_counts": dict(Counter(row["disposition"] for row in boundary_rows)),
            "boundaries": boundary_rows, "assertions": rows,
            "strict_complete": counts["missing"] == 0}


def text_report(report, show_missing):
    print("Compiler language assertions — live observations only")
    print("feature\tcovered\tmissing\tversion-difference\tunrelated")
    for feature, counts in report["features"].items():
        print(feature + "\t" + "\t".join(str(counts.get(key, 0)) for key in
                                               ("covered", "missing", "version-difference", "unrelated")))
    print("TOTAL\t" + "\t".join(str(value) for value in report["counts"].values()))
    layers = {layer: Counter(row["layers"].get(layer, {}).get("status", "not-run")
                             for row in report["assertions"] if row["fixture_id"]) for layer in LAYERS}
    for layer, counts in layers.items():
        print(f"{layer}: " + ", ".join(f"{key}={value}" for key, value in sorted(counts.items())))
    print("Boundary diagnostics (not passing semantic assertions): " + json.dumps(report["boundary_counts"], sort_keys=True))
    for row in report["boundaries"]:
        if row["id"] in ("fn-variadic", "fn-multiple", "special-recur"):
            print(f"  {row['id']}: {row['disposition']} ({row['diagnostic']})")
    if show_missing:
        for row in report["assertions"]:
            if row["status"] == "missing":
                print(f"MISSING {row['id']} [{row['feature']}]: {row['reason']}")
    print("Strict completion: " + ("complete" if report["strict_complete"] else "INCOMPLETE"))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", action="store_true", help="execute witnesses; absent witnesses remain missing")
    parser.add_argument("--strict", action="store_true", help="fail if any selected in-scope assertion is missing")
    parser.add_argument("--feature", action="append", default=[], help="exact feature section; repeatable")
    parser.add_argument("--id", action="append", default=[], help="exact stable assertion ID; repeatable")
    parser.add_argument("--reference", choices=("none", "release", "checkout", "both"), default="both")
    parser.add_argument("--checkout", type=Path, default=ROOT / "research/clojurescript")
    parser.add_argument("--binary", type=Path, help="prebuilt executable (requires --no-build)")
    parser.add_argument("--no-build", action="store_true", help="use an explicitly prebuilt binary")
    parser.add_argument("--timeout", type=float, default=30, help="seconds per local case/layer")
    parser.add_argument("--reference-timeout", type=float, default=180)
    parser.add_argument("--json", action="store_true", help="emit full machine-readable report")
    parser.add_argument("--output", type=Path, help="also save full JSON report")
    parser.add_argument("--show-missing", action="store_true")
    parser.add_argument("--artifacts", type=Path, help="fresh directory for invocations, outputs and report")
    args = parser.parse_args(argv)
    if args.timeout <= 0 or args.reference_timeout <= 0:
        parser.error("timeouts must be positive")
    if args.binary and not args.no_build:
        parser.error("--binary requires --no-build; otherwise use the executable reported by Cargo")
    try:
        inventory, witnesses, cases = load_contract()
        all_features = {row["feature"] for row in inventory.values()}
        if set(args.feature) - all_features or set(args.id) - set(inventory):
            raise ValueError("unknown feature or assertion ID")
        selected = assemble(inventory, witnesses, {}, features=args.feature, identities=args.id)
        selected_ids = {row["fixture_id"] for row in selected["assertions"] if row["fixture_id"]}
        selected_cases = [case for identity, case in cases.items() if identity in selected_ids]
        evidence = {}
        artifacts = None
        binary_identity = None
        if args.run:
            if args.artifacts:
                artifacts = args.artifacts.resolve()
                artifacts.mkdir(parents=True, exist_ok=False)
            else:
                artifacts = Path(tempfile.mkdtemp(prefix="light-cljs-language-"))
            if not args.no_build:
                build = invoke(["cargo", "build", "--locked", "--bin", "light-cljs", "--message-format=json"],
                               artifacts / "cargo", timeout=180)
                if build["status"] != "completed":
                    raise ValueError(f"compiler build failed; artifacts: {artifacts}")
                built = [row["executable"] for row in (json.loads(line) for line in build["stdout"].splitlines())
                         if row.get("reason") == "compiler-artifact" and row["target"]["name"] == "light-cljs"
                         and row.get("executable")]
                if len(built) != 1:
                    raise ValueError(f"Cargo did not identify exactly one compiler executable; artifacts: {artifacts}")
                binary = str(Path(built[0]).resolve())
            else:
                binary = str((args.binary or ROOT / "target/debug/light-cljs").resolve())
            binary_identity = {"path": binary, "sha256": hashlib.sha256(Path(binary).read_bytes()).hexdigest()}
            for case in selected_cases:
                evidence[case["id"]] = local_layers(case, binary, artifacts / "local" / case["id"], args.timeout)
            for kind in ("release", "checkout"):
                if args.reference not in (kind, "both") or not selected_cases:
                    continue
                expected = {identity: case["expected"] for identity, case in cases.items()}
                for witness in witnesses.values():
                    if witness.get("version_difference"):
                        expected[witness["fixture_id"]] = witness["version_difference"][kind]
                reference_inputs = [{**case, "expected": expected[case["id"]]} for case in selected_cases]
                for identity, observed in reference_cases(reference_inputs, kind, args.checkout.resolve(),
                                                           artifacts / kind, args.reference_timeout).items():
                    evidence[identity][kind] = observed
        report = assemble(inventory, witnesses, evidence, features=args.feature, identities=args.id)
        if artifacts:
            report["artifacts"] = str(artifacts)
            report["compiler_binary"] = binary_identity
            (artifacts / "report.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
        encoded = json.dumps(report, indent=2) + "\n"
        if args.output:
            args.output.write_text(encoded, encoding="utf-8")
        if args.json:
            print(encoded, end="")
        else:
            text_report(report, args.show_missing)
            if artifacts:
                print(f"Artifacts: {artifacts}")
        # Focused implementation runs may reject missing features. A changed
        # value, invalid harness output, timeout or missing reference is a real
        # run failure, even outside strict mode. Rejections never become passes.
        failure_statuses = {"mismatch", "invalid-output", "invalid-reference", "failed",
                            "unavailable", "reference-unavailable", "timed-out"}
        failed = any(layer.get("status") in failure_statuses for result_layers in evidence.values()
                     for layer in result_layers.values())
        return 1 if failed or (args.strict and not report["strict_complete"]) else 0
    except (ValueError, KeyError, OSError) as error:
        print(f"coverage contract error: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
