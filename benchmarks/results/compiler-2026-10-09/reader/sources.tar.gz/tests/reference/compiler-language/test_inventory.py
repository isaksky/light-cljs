#!/usr/bin/env python3
"""Extractor checks using synthetic source only; no research checkout required."""

import contextlib
import importlib.util
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
SPEC = importlib.util.spec_from_file_location("language_inventory", Path(__file__).with_name("extract_inventory.py"))
inv = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = inv
SPEC.loader.exec_module(inv)


class InventoryTests(unittest.TestCase):
    def generate(self, text, path="src/test/cljs/cljs/example.cljs"):
        with patch.object(inv, "FILES", (path,)), patch.object(inv.subprocess, "check_output", return_value=text.encode()):
            result, manifest = inv.inventory(check_checkout=False)
        rows = [json.loads(line) for line in result["inventory.jsonl"].splitlines()]
        bodies = [json.loads(line) for line in result["bodies.jsonl"].splitlines()]
        return result, manifest, rows, bodies

    def test_full_bodies_helpers_and_zero_assertion_tests_are_retained(self):
        text = "; License notice\n(ns sample)\n(defn helper [x] (is x))\n(deftest calls-helper (helper true))\n(deftest nested (doseq [x [1 2]] (is (= x x))))"
        _, manifest, rows, bodies = self.generate(text)
        self.assertEqual(len(bodies), 4)
        self.assertEqual(len(rows), 2)
        self.assertEqual(manifest["zero_assertion_tests"], ["example.cljs::calls-helper"])
        self.assertEqual(bodies[2]["source_span"]["text"], "(deftest calls-helper (helper true))")
        self.assertEqual(rows[0]["body_id"], "example.cljs::helper")
        self.assertEqual(rows[1]["context"][0]["head"], "doseq")
        self.assertTrue(all(row["status"] == "missing" for row in rows))

    def test_reader_literals_do_not_create_phantom_assertions(self):
        text = r'''(deftest literals
          ; (is false)
          (is (= "(is false)" "(is false)"))
          (is (= #"[(]is[)]" #"[(]is[)]"))
          (is (= [\) \; \" \\ \space \newline] [\) \; \" \\ \space \newline]))
          (is (= #:foo{:x 1} #::{:x 1}))
          (is (= #js [1] #js [1]))
          (is (= ##Inf ##Inf)))'''
        _, _, rows, _ = self.generate(text)
        self.assertEqual(len(rows), 6)
        for row in rows:
            span = row["assertion"]
            self.assertEqual(text.encode()[span["start_byte"]:span["end_byte"]].decode(), span["text"])

    def test_unicode_offsets_are_bytes_and_expected_forms_are_not_rewritten(self):
        text = '(deftest unicode (is (= "é♯" "é♯")) (is (= \'(1)) (apply f [1])))'
        _, _, rows, _ = self.generate(text)
        self.assertEqual(len(rows), 2)
        span = rows[1]["assertion"]
        self.assertEqual(span["text"], "(is (= '(1)) (apply f [1]))")
        self.assertEqual(text.encode()[span["start_byte"]:span["end_byte"]].decode(), span["text"])
        self.assertEqual(inv.digest(span["text"].encode()), span["sha256"])

    def test_are_expands_rows_and_retains_template_arguments_and_scope(self):
        text = "(deftest rows (are [expected expr] (= expected expr) [] (vec nil) {} (sorted-map)))"
        _, _, rows, _ = self.generate(text)
        self.assertEqual(len(rows), 2)
        self.assertEqual([r["status"] for r in rows], ["missing", "unrelated"])
        self.assertEqual(rows[1]["category"], "sorted-collections")
        self.assertEqual(rows[0]["are"]["template"]["text"], "(= expected expr)")
        self.assertEqual([x["text"] for x in rows[0]["are"]["arguments"]], ["[]", "(vec nil)"])
        self.assertEqual(rows[0]["are"]["row_source"]["text"], "[] (vec nil)")
        self.assertEqual(rows[0]["assertion"], rows[1]["assertion"])
        self.assertNotEqual(rows[0]["id"], rows[1]["id"])
        with self.assertRaisesRegex(ValueError, "Incomplete are row"):
            self.generate("(deftest bad (are [x y] (= x y) 1))")

    def test_inactive_branches_and_nested_thrown_are_counted_honestly(self):
        text = """(deftest active
          (is (thrown? js/Error (f)))
          #_(is false)
          '(is false)
          (comment (is false))
          #?(:clj (is false) :cljs (is true)))"""
        _, manifest, rows, _ = self.generate(text)
        self.assertEqual(len(rows), 6)
        self.assertEqual(manifest["counts"]["active_assertions"], 2)
        self.assertEqual([r["inactive_reason"] for r in rows],
                         [None, "reader-discarded", "quoted-data", "comment-form", "non-cljs-reader-branch", None])

    def test_assert_and_quantified_property_are_not_omitted(self):
        _, _, rows, _ = self.generate("(deftest ordinary (assert (not= 1 2))) (defspec property 10 (prop/for-all [b gen/boolean] (boolean? b)))")
        self.assertEqual([r["kind"] for r in rows], ["assert", "property"])
        self.assertIn("prop/for-all", rows[1]["assertion"]["text"])

    def test_scope_distinguishes_local_dependencies_and_quoted_data(self):
        text = """(defmulti bar identity)
          (deftest mixed
            (let [plain #{1} sorted (sorted-set 1)]
              (is (= plain #{1}))
              (is (= sorted #{1})))
            (is (= (vary-meta #'first assoc :x 'bar) #'first))
            (is (bar 1))
            (is (= [2] (map inc [1])))
            (is (map inc)))"""
        _, _, rows, _ = self.generate(text)
        self.assertEqual([r["category"] for r in rows], ["source-language", "sorted-collections", "source-language",
                                                         "multimethods-hierarchies", "source-language", "transducers"])

    def test_snapshot_omission_changes_regeneration_and_check_fails(self):
        original, _, _, _ = self.generate("(deftest t (is true) (is false))")
        omitted, _, _, _ = self.generate("(deftest t (is true))")
        self.assertNotEqual(original["inventory.jsonl"], omitted["inventory.jsonl"])
        self.assertNotEqual(original["bodies.jsonl"], omitted["bodies.jsonl"])
        for filename in ("inventory.jsonl", "bodies.jsonl", "manifest.json"):
            with self.subTest(filename=filename), tempfile.TemporaryDirectory() as temp:
                root = Path(temp)
                for name, data in original.items():
                    (root / name).write_bytes(data)
                (root / filename).write_bytes(omitted[filename])
                with patch.object(inv, "HERE", root), patch.object(inv, "inventory", return_value=(original, {})), \
                     patch.object(sys, "argv", ["extract_inventory.py", "--check"]), contextlib.redirect_stderr(io.StringIO()) as err:
                    self.assertEqual(inv.main(), 1)
                    self.assertIn(filename, err.getvalue())

    def test_modified_upstream_working_bytes_fail_even_if_snapshot_is_regenerated(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "source.cljs").write_text("(deftest t (is false))")
            with patch.object(inv, "UPSTREAM", root), patch.object(inv, "FILES", ("source.cljs",)), \
                 patch.object(inv.subprocess, "check_output", return_value=b"(deftest t (is true))"):
                with self.assertRaisesRegex(ValueError, "working source differs from pin"):
                    inv.inventory()

    def test_invalid_structural_source_fails_instead_of_losing_tail(self):
        for source in ('(is true', '(is ] true)', '(is "unterminated)', "#", "#?(:cljs)"):
            with self.subTest(source=source), self.assertRaises(ValueError):
                self.generate(source)


if __name__ == "__main__":
    unittest.main()
