# Compiler-language source inventory

This inventory retains the eleven complete upstream test files named in the
compiler language coverage work, at ClojureScript commit
`a5e94c988fd0b50ffcff1ce6add12ffbb7839a3e`. It records source assertions and
their original expectations. It does not report them executed. See
[evidence.md](evidence.md) for executable witnesses, reports, and strict versus
focused commands.

```sh
python3 tests/reference/compiler-language/extract_inventory.py
python3 tests/reference/compiler-language/extract_inventory.py --check
python3 tests/reference/compiler-language/test_inventory.py
```

Extraction and checking require the pinned Git object and byte-identical source
files under `research/clojurescript`. The extractor uses Python's standard
library and Git; the unit checks use synthetic source and require no checkout,
Clojure, Java, Node, or network. `--check` writes nothing and compares regenerated
inventory, bodies, and manifest byte for byte. Removing a row, omitting a test
body, changing an expectation, changing a scope rule, or altering pinned source
fails that check until the change is explicitly regenerated and reviewed.

## Files and identity

`inventory.jsonl` has one row per source assertion site. IDs are
`source-basename::top-level-name::assertion-NNN`, numbered in source order within
the complete top-level form. Repeated top-level names get a `~N` suffix. IDs are
stable for this pinned source, independent of execution outcomes or disposition.
A later upstream revision may require an explicit mapping migration.

Each row has `source`, `test`, `body_id`, `body_sha256`, primary `feature`, all
detected `features`, `status`, `disposition`, `category`, `reason`, `active`, and
`inactive_reason`. `assertion` contains its verbatim source, SHA-256, one-based
inclusive line numbers, and zero-based UTF-8 byte offsets with an exclusive end.
`context` locates enclosing binding/iteration/testing forms within the body.

`bodies.jsonl` retains **every complete top-level form**, including namespace
declarations, fixture values, definitions, helper functions, test bodies with no
assertion macros, and reader-discarded forms. Its `source_span` uses the same
lossless source-span schema, and `assertions` gives all associated assertion IDs.
`kind` distinguishes tests from support forms. Helpers are not omitted because
their assertions happen outside a `deftest`: for example, `metadata_test.cljc`
asserts within three shared interface helpers. The full calling test body and
all of its collection/sequence inputs remain available alongside them.

`manifest.json` records the revision, complete source-file hashes, per-file
counts and original copyright/license notices, extractor and output hashes,
feature/category/status counts, and zero-assertion test IDs. Byte hashes cover
comments and whitespace even though comments are not assertion sites. The
upstream source retains its Eclipse Public License 1.0 attribution; inventory
source excerpts are covered by the original notices retained in the manifest.

## What an assertion counts

The structural reader handles strings, regexes, characters, all delimiters,
reader prefixes, tags, namespaced maps, anonymous functions, metadata, symbolic
numbers, and conditionals. It recognizes `is`, `assert`, `are`, and `defspec`,
including qualified names. `thrown?` and related expectations stay inside their
enclosing `is`; they are not counted twice. Each `are` argument row is a separate
record, retaining the complete original `are` expression plus its parameter
vector, template, and exact argument/source spans. Incomplete rows fail
extraction. A `defspec` records the whole quantified property, including its
generator; it does not claim a fixed number of generated cases.

An `is` message expression is preserved as a message. For example, several
upstream apply/bit-operation assertions put a second expression outside the
equality predicate. Extraction neither silently moves that expression into the
predicate nor asserts stronger behavior than the original test.

Counts are **source sites**, not dynamic assertion invocations. Loop iterations,
helper arguments, setup, mutation order, exception paths and fixture dependencies
remain part of the complete bodies. A future adapter must preserve that context
before claiming coverage. A body containing no assertion macros is explicitly
listed; it must not be converted into a passing assertion. `#_`-discarded,
comment-form, quoted-data, and non-CLJS conditional assertions are retained with
an inactive reason and cannot increase the active or passing counts.

## Scope and statuses

The primary sections are functions/apply, recursion, bindings/control, mutable
state, protocols/types/records, reader/metadata, exceptions, core helpers, lazy
sequences, JavaScript interop, and namespaces. Every active source-language
assertion begins `missing`. Current compiler rejection, interpreter support, or
a superficially similar fixture is not evidence of a pass. Checkout-only syntax
also begins `missing`; a `version-difference` needs explicit version-specific
execution evidence elsewhere.

Whole-file retention makes scope exclusions reviewable. Exact upstream AST
fields, generated JavaScript spelling/optimization shape, constant naming,
compiler cache APIs, and private storage helper tests are explicitly
`upstream-internals`. Source namespace validation, rejected malformed syntax,
overload/recur rules, and compiler warnings remain source-language obligations.

The named group excludes sorted/transient collection implementations,
transducer constructor/execution APIs, standalone library namespaces, and
unrequested multimethod/hierarchy and tap-delivery APIs. These have separate
categories and reasons. The extractor follows named fixture/local references
to classify mixed bodies per assertion: a normal set assertion stays in scope
beside a sorted-set assertion, and a collection-taking `map` stays in scope
beside its transducer constructor arity. The full body is retained in both
cases. Built-in tagged values, core printing, regexes, metadata, lazy traversal,
protocol extension, and host array/object behavior are not excluded merely
because implementation is missing.

Scope rules are versioned in the extractor, not inferred from runtime failures.
Classification is source-level inventory guidance, not an executable dependency
resolver or a proof that a extracted assertion can run independently. Complete
setup/helper/iteration preservation must be checked when adding witnesses.
