#!/usr/bin/env python3
"""Accounting tests intentionally inject lost, skipped and failing observations."""
import contextlib
import copy
import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.dont_write_bytecode = True
import report


class AccountingTests(unittest.TestCase):
    def setUp(self):
        self.row = {"disposition": "in-scope", "reason": "source language assertion"}
        self.witness = {"fixture_id": "example"}
        self.complete = {"example": {layer: {"status": "passed"} for layer in report.SEMANTIC_LAYERS}}
        self.case = {"id": "example", "source": "true", "expected": {"id": "example", "outcome": {"status": "returned", "value": True},
                                                     "trace": [], "stdout": ""}}

    def test_only_complete_current_compiler_and_both_references_cover(self):
        self.assertEqual(report.classify(self.row, self.witness, self.complete)[0], "covered")
        self.assertEqual(report.classify(self.row, None, self.complete)[0], "missing")
        self.assertEqual(report.classify(self.row, self.witness, {})[0], "missing")
        self.assertEqual(report.classify(self.row, self.witness, {"example": {
            "lexer": {"status": "accepted"}, "parser": {"status": "accepted"},
            "native": {"status": "passed"}}})[0], "missing")

    def test_every_nonpass_status_stays_missing_in_every_required_layer(self):
        for layer in report.SEMANTIC_LAYERS:
            for status in ("missing", "rejected", "skipped", "not-run", "timed-out", "reference-unavailable",
                           "invalid-reference", "invalid-output", "unavailable", "failed", "mismatch", "accepted"):
                with self.subTest(layer=layer, status=status):
                    evidence = {"example": {key: dict(value) for key, value in self.complete["example"].items()}}
                    evidence["example"][layer] = {"status": status}
                    self.assertEqual(report.classify(self.row, self.witness, evidence)[0], "missing")
            evidence = {"example": {key: value for key, value in self.complete["example"].items() if key != layer}}
            self.assertEqual(report.classify(self.row, self.witness, evidence)[0], "missing")

    def test_version_differences_and_unrelated_assertions_never_increase_passing_count(self):
        witness = {**self.witness, "version_difference": {"reason": "verified release/checkpoint difference"}}
        self.assertEqual(report.classify(self.row, witness, self.complete)[0], "version-difference")
        self.assertEqual(report.classify(self.row, witness, {})[0], "missing")
        self.assertEqual(report.classify({"disposition": "unrelated", "reason": "upstream AST shape"},
                                         self.witness, self.complete)[0], "unrelated")

    def test_outcomes_require_exact_ids_order_count_and_fields(self):
        one = json.dumps(self.case["expected"])
        second = {"id": "next", "expected": {**self.case["expected"], "id": "next"}}
        two = json.dumps(second["expected"])
        for output in ("", one, one + "\n" + one, two + "\n" + one,
                       one + "\n" + two + "\n" + one, "crashed", "null", "42"):
            with self.subTest(output=output):
                values = report.observations(output, [self.case, second])
                self.assertFalse(any(row["status"] == "passed" for row in values.values()))
        values = report.observations(one + "\n" + two + "\n", [self.case, second])
        self.assertEqual([row["status"] for row in values.values()], ["passed", "passed"])
        partial = json.dumps({"id": "example", "outcome": self.case["expected"]["outcome"]})
        self.assertEqual(report.observations(partial, [self.case])["example"]["status"], "invalid-output")
        for invalid in (one.replace('"value": true', '"value": false, "value": true'),
                        one.replace('"value": true', '"value": NaN')):
            self.assertEqual(report.observations(invalid, [self.case])["example"]["status"], "invalid-output")

    def test_expected_failures_are_compared_as_outcomes_not_passing_by_exception(self):
        case = {"id": "throws", "expected": {"id": "throws", "outcome": {
            "status": "threw", "error": {"category": "type-error"}}, "trace": [1], "stdout": "before\n"}}
        self.assertEqual(report.observations(json.dumps(case["expected"]), [case])["throws"]["status"], "passed")
        for change in ({"trace": []}, {"stdout": ""}, {"outcome": {"status": "returned", "value": None}}):
            self.assertEqual(report.observations(json.dumps({**case["expected"], **change}), [case])["throws"]["status"],
                             "mismatch")

    def test_boolean_number_confusion_cannot_pass(self):
        actual = {**self.case["expected"], "outcome": {"status": "returned", "value": 1}}
        self.assertEqual(report.observations(json.dumps(actual), [self.case])["example"]["status"], "mismatch")
        self.assertFalse(report.same_json([True], [1]))
        self.assertTrue(report.same_json(1, 1.0))

    def test_process_failure_timeout_and_missing_executable_are_not_success(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for name, command, status in (
                ("crash", [sys.executable, "-c", "print('partial'); raise SystemExit(3)"], "failed"),
                ("timeout", [sys.executable, "-c", "import time; print('partial', flush=True); time.sleep(10)"], "timed-out"),
                ("absent", [str(root / "nonexistent-tool")], "unavailable"),
            ):
                observed = report.invoke(command, root / name, timeout=0.1)
                self.assertEqual(observed["status"], status)
                self.assertTrue((root / name / "invocation.json").exists())

    def test_process_output_preserves_crlf_and_rejects_invalid_utf8(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            crlf = report.invoke([sys.executable, "-c", "import sys; sys.stdout.buffer.write(b'first\\r\\nlast\\r\\n')"],
                                 root / "crlf")
            self.assertEqual(crlf["stdout"], "first\r\nlast\r\n")
            invalid = report.invoke([sys.executable, "-c", "import sys; sys.stdout.buffer.write(b'\\xff')"],
                                    root / "invalid")
            self.assertEqual(invalid["status"], "invalid-output")

    def test_reference_success_requires_pinned_identity_effective_options_and_output(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            # A successful launcher with omitted build evidence is not a reference.
            with patch.object(report, "invoke", return_value=report.result("completed", stdout="", stderr="")):
                values = report.reference_cases([self.case], "release", root, root / "run", 1)
                self.assertEqual(values["example"]["status"], "invalid-reference")
            with patch.object(report, "invoke", return_value=report.result("unavailable", "Clojure missing")):
                values = report.reference_cases([self.case], "release", root, root / "absent", 1)
                self.assertEqual(values["example"]["status"], "reference-unavailable")
            (root / "reference.js").write_text("", encoding="utf-8")
            verified = ("REFERENCE IDENTITY release 1.12.134\n"
                        "REFERENCE SETTINGS {:optimizations :none, :static-fns false, :def-emits-var false}")
            with patch.object(report, "invoke", side_effect=[report.result("completed", stdout=verified),
                              report.result("completed", stdout=json.dumps(self.case["expected"]))]) as invoke:
                self.assertEqual(report.reference_cases([self.case], "release", root, root, 7)["example"]["status"],
                                 "passed")
                self.assertEqual(invoke.call_args_list[-1].kwargs["timeout"], 7)


class InventoryTests(unittest.TestCase):
    def test_live_contract_contains_complete_bodies_and_traceable_witnesses(self):
        inventory, witnesses, cases = report.load_contract()
        self.assertGreater(len(inventory), len(witnesses))
        self.assertTrue(cases)
        for witness in witnesses.values():
            self.assertIn(witness["fixture_id"], cases)

    def test_current_report_is_missing_until_execution_and_strict_fails(self):
        inventory, witnesses, _ = report.load_contract()
        assembled = report.assemble(inventory, witnesses, {})
        self.assertEqual(assembled["counts"]["covered"], 0)
        self.assertGreater(assembled["counts"]["missing"], 0)
        self.assertFalse(assembled["strict_complete"])
        with contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(report.main(["--strict"]), 1)

    def test_invalid_selection_cannot_appear_complete(self):
        with contextlib.redirect_stderr(io.StringIO()):
            self.assertEqual(report.main(["--strict", "--id", "not-an-assertion"]), 2)
            self.assertEqual(report.main(["--feature", "not-a-feature"]), 2)

    def test_version_expectations_preserve_types_and_shared_fixture_contracts(self):
        _, witnesses, cases = report.load_contract()
        original_jsonl = report.jsonl

        def load_with(rows):
            def data(path):
                return rows if path.name == "witnesses.jsonl" else original_jsonl(path)
            with patch.object(report, "jsonl", side_effect=data):
                return report.load_contract()

        rows = copy.deepcopy(list(witnesses.values()))
        expected = copy.deepcopy(cases[rows[0]["fixture_id"]]["expected"])
        release = copy.deepcopy(expected)
        release["outcome"]["value"] = 1
        rows[0]["version_difference"] = {"reason": "injected explicit numeric versus boolean contract",
                                         "release": release, "checkout": expected}
        # true and 1 are a real contract difference, not Python-equal values.
        load_with(rows)
        bad_checkout = copy.deepcopy(rows)
        bad_checkout[0]["version_difference"] = {"reason": "injected wrong checkout expectation",
                                                 "release": expected, "checkout": release}
        with self.assertRaisesRegex(ValueError, "checkout must remain"):
            load_with(bad_checkout)
        # An unselected witness cannot silently overwrite another assertion's
        # pinned reference expectations through a shared fixture.
        rows[1]["fixture_id"] = rows[0]["fixture_id"]
        with self.assertRaisesRegex(ValueError, "inconsistent reference expectations"):
            load_with(rows)

    def test_signature_and_recur_rejections_are_missing_capabilities_not_negative_tests(self):
        boundaries = {row["id"]: row for row in report.boundary_inventory()}
        for identity in ("fn-variadic", "fn-multiple", "special-recur", "special-loopstar"):
            row = boundaries[identity]
            self.assertEqual(row["disposition"], "accepted-boundary" if row["local_category"] == "accepted"
                             else "missing-capability")
        for identity in ("if-empty", "fn-variadic-missing-rest", "reader-map-duplicate", "def-missing"):
            self.assertEqual(boundaries[identity]["disposition"], "negative-test")


if __name__ == "__main__":
    unittest.main()
