# Executable compiler language coverage

This inventory measures source assertions in eleven explicitly inventoried files
at ClojureScript **a5e94c988fd0b50ffcff1ce6add12ffbb7839a3e**. It is a coverage
matrix, not a task queue or a claim to execute the entire upstream suite.
[README.md](README.md) defines extraction, complete-body retention, stable IDs,
section scope and unrelated dispositions. [manifest.json](manifest.json) gives
the exact inventory counts. Original assertion expressions and expectations are
retained; old passing execution fixtures and invalid-source diagnostics are
unchanged.

## Commands

Run from the repository root with Python 3.10+. Node is needed for generated
JavaScript. Clojure CLI, Java, Maven 1.12.134 dependencies and the pinned clean
research checkout are needed for both references.

```sh
# Source evidence and checked inventory completeness; no test execution claim.
python3 -B tests/reference/compiler-language/extract_inventory.py --check

# Report all assertions, with no cached or fabricated passes.
python3 -B tests/reference/compiler-language/report.py --show-missing

# Default reference selection is both; rejection stays visible as missing.
python3 -B tests/reference/compiler-language/report.py --run --feature functions-apply

# Inspect a single assertion, retaining its complete upstream body in the inventory.
python3 -B tests/reference/compiler-language/report.py --run --strict \
  --id 'core_test.cljs::test-401-411::assertion-001'

# Whole-inventory completion gate. Intentionally exits 1 at this baseline.
python3 -B tests/reference/compiler-language/report.py --run --strict \
  --output /tmp/compiler-language.json

# Fast local feedback cannot establish reference conformance.
python3 -B tests/reference/compiler-language/report.py --run --reference none \
  --feature functions-apply

# Fast accounting, existing runtime regressions and provenance.
cargo test --locked --test compiler_language --test provenance --test execution
```

`--feature` and `--id` are exact, repeatable filters. Features select the
inventory's primary feature section; each row also retains other relevant
features for navigation. Unknown/empty selections are errors, not zero-test
successes. `--json` emits every selected assertion, its disposition, source
anchor, fixture ID and observed backend results. `--output` saves the same JSON.
`--show-missing` prints stable missing IDs and concrete reasons.

Normal runs build the current compiler and use the executable path returned by
Cargo, including when `CARGO_TARGET_DIR` is configured. `--no-build` explicitly
uses `target/debug/light-cljs`; combine it with `--binary PATH` for another
prebuilt executable. Reports record its path and SHA-256. `NODE` and `CLOJURE`
select executable paths; the fast Rust accounting test also honors `PYTHON`.
`--checkout` selects the reference source directory, while its required revision
remains pinned. There is no automatic checkout/release substitution.

Each execution keeps a fresh temporary artifact directory with invocation
arguments, exact stdin/source, stdout, stderr, reference builds and `report.json`.
`--artifacts PATH` selects a new directory explicitly; existing directories are
rejected to avoid mixing observations. Local layers have individual timeouts
(`--timeout`, default 30 seconds). Reference compilation and Node execution each
use `--reference-timeout` (default 180 seconds).
On POSIX, timeout cleanup kills only the owned process group. File-backed output
preserves partial diagnostics without waiting for pipe-holding descendants.

## Meaning of the result columns

The new [six-column fixture file](../../fixtures/compiler-language.tsv) records
ID, source, expected outcome JSON, effect trace JSON, stdout JSON and an optional
native stdout expectation. Its [witness mappings](witnesses.jsonl) pin the exact
original assertion hash and explain each adaptation. The existing
[provenance sidecar](../fixture-origins.tsv) also covers every new fixture.

Lexer and parser **acceptance** say only that syntax was handled. Native
**passed** means that the native result matched its separately declared
expectation; CLJS-specific host values or protocol contracts can be explicitly
inapplicable to that backend. Neither contributes to compiler coverage.

Generated JavaScript is compiled independently for every witness and executed
with the existing [outcome runner](../../support/execution.js). The same
`{id, outcome, trace, stdout}` protocol and private-runtime inspection adapter
used by `tests/execution.rs` are retained. The release and checkout run the same
sources through [execution.clj](../execution.clj), which verifies the effective
revision and `:optimizations :none`, `:static-fns false`, `:def-emits-var false`
on every build. Returned values, thrown categories, effects and stdout are all
compared to literal expected outcomes, not just to each other.

An assertion is **covered** only when its complete faithful witness passes
generated JavaScript **and both** pinned references in the current invocation.
No witness, omitted backend, compiler rejection, skip, timeout, unavailable
reference, malformed output, duplicate ID, partial process output or mismatch
can increase that count. Outcomes must contain exactly the expected IDs in order
with every protocol field. JSON booleans cannot equal numeric 0/1 accidentally.
Known native successes therefore cannot conceal missing JavaScript support.

**Version difference** is a separate disposition, never a pass. A witness may
declare `version_difference` with an explanation and distinct complete
`release`/`checkout` expected protocol objects. The checkout object must match
the fixture's original expectation. Only successful observations of both
versioned expectations and the generated JavaScript contract establish that
disposition. A missing tool, rejection, or guessed release limitation cannot.
No version-difference witness has been asserted at this baseline; checkout-only
syntax stays missing until someone supplies and executes explicit evidence.

**Unrelated** records concern upstream internals, deliberately excluded library
or build features, or inactive source assertions. Reasons remain per assertion.
They do not contribute to the passing count. Strict completion requires zero
missing selected in-scope assertions; verified version differences remain
separately reported. Focused runs may exit 0 with rejected features visible,
but mismatches, failed processes, invalid protocol, timeouts and unavailable
tools still exit nonzero. `--strict` additionally fails every missing assertion.
A report-only invocation establishes no new passes and normally fails strict
completion until it is executed.

The report also reads the current `analysis-boundaries.tsv` as a separate table.
Valid reference-accepted multiple-arity, variadic and recur rejection rows are
**missing capabilities**. Actual invalid-source errors stay **negative tests**.
Those diagnostic rows are never added to executable semantic passing counts.
Their existing analyzer/API/CLI tests and reference classifications are preserved.

## Baseline observed on 2026-10-09 (America/Denver)

The first executable witness set contains **25 assertion-faithful adaptations**.
It retains whole tested operations: apply and its sequence tail, multi/variadic
arity clauses, loop/recur, mutual letfn and reify protocol wrappers. It does not
replace these with direct calls, maps or other already-supported equivalents.

| Backend | Observed result for the 25 witnesses |
| --- | --- |
| Lexer | 25 accepted |
| Parser | 25 accepted |
| Native interpreter | 22 passed; 3 explicitly inapplicable CLJS host/protocol cases |
| Generated JavaScript | 5 passed; 20 rejected and retained as missing |
| Maven ClojureScript 1.12.134 | 25 matched complete expected outcomes |
| Pinned checkout (reported runtime 0.0.135109660) | 25 matched complete expected outcomes |

The **5 covered** assertion sites are basic equality, zero/three-argument
addition, and two original closure/rebinding assertions. Existing independently
written or reduced probes do not automatically cover an upstream assertion;
the remaining inventory is conservatively missing until faithful evidence is
mapped and executed. See the manifest for total and unrelated counts, and run
the report for current missing counts. These are source assertion sites, not
dynamic `doseq`/property iteration counts and not a whole-suite percentage.

With the final scope dispositions, the **2,213** inventoried source assertion
sites comprise **5 covered, 1,761 missing, 0 verified version differences and
447 unrelated**. All **556** complete top-level test/helper/fixture forms are
retained. Before execution, a report-only invocation correctly gives zero
covered and 1,766 missing. These baseline counts do not replace the live report.

Reproduction of that baseline used:

```sh
python3 -B tests/reference/compiler-language/report.py --run --no-build \
  --reference both --output /tmp/light-cljs-language-baseline.json
```

The reference runs verified Maven 1.12.134 and the pinned checkout identity before
and after compilation, with effective settings above, Clojure **1.12.4** and
Java **25.0.2**. The full 25-witness run passed its comparison checks while
reporting the 20 JavaScript rejections; strict completion remains incomplete.
The focused closure command above separately checks that a fully observed
single-assertion selection can pass strict mode.

The fast accounting suite explicitly tests missing/rejected/skipped/timed-out/
reference-unavailable paths, partial/duplicate/reordered output, stdout and
effect mismatches, version-difference separation, invalid selections and the
boundary diagnostic distinction. The Rust integration test, two provenance
tests and 24 existing execution tests passed; eight existing explicit reference
tests stayed ignored in that fast run. The new witnesses were compared to both
references with the command above. Formatting and focused Clippy also passed.

## Updating coverage with a language implementation

Read the original complete body, referenced fixture/helper setup and all relevant
assertions before adding a witness. Preserve the tested language operation,
bindings, effects, expected values and failure behavior. An adaptation that
removes the feature under test must remain missing. Give each new executable
case an independent stable fixture ID and add its traceable provenance, original
assertion hash and rationale to the mapping. Dynamic/helper assertions require
all relevant calling contexts, not just one convenient passing iteration.

Run the selected section and both pinned references. Add independent direct
runtime checks where the shared encoder might conceal a bug. Update this
baseline's historical narrative only by adding dated evidence; the runner
always derives current coverage from current observations. Updating the source
inventory is explicit: adjust justified section classifications in the extractor,
regenerate, and review complete bodies, changed assertions and manifest counts.
`--check` detects omission or source drift; no unsupported implementation should
be reclassified as unrelated to make strict completion pass.

## Reader member — 2026-10-09

Reader lowering adds eleven faithful witnesses from the complete
`primitives_test.cljs/test-regexps` body: assertion 001 and assertions 003–012.
The manifest retains the original hashes and exact bindings/expressions; the
second assertion still requires `js*` and remains missing. The focused strict
run passed all eleven in generated JavaScript, Maven 1.12.134 and the pinned
checkout, with all values, traces and stdout checked. Native results are
explicitly inapplicable for these compiler/JavaScript regex witnesses.

The inventory itself is unchanged and `extract_inventory.py --check` passes.
The original baseline counts above remain historical. The live report derives
current coverage; this focused result is not completion of all reader/metadata
or interop assertions elsewhere in the retained files.

The [reader audit](../compiler-reader.md) records thirteen additional original
Date assertions from `reader_test.cljs`, independent literal/macro/alias/error
probes, numeric reader behavior, verification commands and measured output cost.
Those Date assertions are tracked in `fixture-origins.tsv`; they are outside the
eleven-file inventory and do not inflate its covered count.
