//! Native compiler macro integration. CLJS environment/resolution observations
//! are anchored in tests/reference/compiler-macros.md; tests need only Rust/Node.
use light_cljs::interpreter::{
    Arity, Name, NativeDefinition, NativeEffects, NativeMetadata, Reload, ResourceLimits,
};
use light_cljs::{
    MacroHost, MacroImport, analyze_with_macros, compile, compile_namespace,
    compile_namespace_with_macros, compile_with_macros, emit_js, parse,
};
use std::{
    fs,
    path::PathBuf,
    process::Command,
    sync::atomic::{AtomicUsize, Ordering},
};

static NEXT: AtomicUsize = AtomicUsize::new(0);
struct Sources(PathBuf);
impl Sources {
    fn new() -> Self {
        let path = std::env::temp_dir().join(format!(
            "light-cljs-macros-{}-{}",
            std::process::id(),
            NEXT.fetch_add(1, Ordering::Relaxed)
        ));
        fs::create_dir_all(&path).unwrap();
        Self(path)
    }
    fn write(&self, path: &str, source: &str) {
        let path = self.0.join(path);
        fs::create_dir_all(path.parent().unwrap()).unwrap();
        fs::write(path, source).unwrap();
    }
    fn compile(&self, entry: &str) -> Result<String, light_cljs::NamespaceCompileError> {
        compile_namespace(entry, std::slice::from_ref(&self.0))
    }
    fn compile_host(
        &self,
        entry: &str,
        host: &mut MacroHost,
    ) -> Result<String, light_cljs::NamespaceCompileError> {
        compile_namespace_with_macros(entry, std::slice::from_ref(&self.0), host)
    }
}
impl Drop for Sources {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}
fn execute(js: &str) -> String {
    let output = Command::new(std::env::var_os("NODE").unwrap_or_else(|| "node".into()))
        .args(["--eval", js])
        .output()
        .expect("compiler integration requires Node");
    assert!(
        output.status.success(),
        "{}\n{js}",
        String::from_utf8_lossy(&output.stderr)
    );
    String::from_utf8(output.stdout).unwrap()
}
fn result(js: &str) -> String {
    execute(&format!("console.log({js});"))
}
fn host(source: &str, refers: &[&str]) -> MacroHost {
    let mut host = MacroHost::new();
    host.context_mut().eval_string(source).unwrap();
    host.set_imports(
        "cljs.user",
        vec![MacroImport {
            namespace: "macros".into(),
            alias: Some("m".into()),
            refers: refers.iter().map(|s| (*s).into()).collect(),
        }],
    )
    .unwrap();
    host
}

#[test]
fn two_runtime_namespaces_use_native_clj_macros_through_api_and_cli() {
    let root = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("examples/macros");
    assert_eq!(
        execute(&compile_namespace("demo.main", std::slice::from_ref(&root)).unwrap()),
        "12\n"
    );
    let output = Command::new(env!("CARGO_BIN_EXE_light-cljs"))
        .args(["--compile", "--entry", "demo.main", "--source-root"])
        .arg(root)
        .output()
        .unwrap();
    assert!(
        output.status.success(),
        "{}",
        String::from_utf8_lossy(&output.stderr)
    );
    assert_eq!(execute(&String::from_utf8(output.stdout).unwrap()), "12\n");
}

#[test]
fn ordinary_core_macros_expand_inside_lexical_environments() {
    let source = r#"
        (defn choose "doc" {:private true} [x]
          (let [x (if x 4 5)] (when x (-> x (js/Math.imul 2)))))
        (def make (fn [x] (fn [] (or nil x))))
        (js/console.log (choose false) ((make 7)) (cond false 0 true 9) (and true 12))
    "#;
    assert_eq!(execute(&compile(source).unwrap()), "10 7 9 12\n");
    assert_eq!(
        result(&compile("(cljs.core/let [x 4] ((clojure.core/fn [y] y) x))").unwrap()),
        "4\n"
    );
}

#[test]
fn locals_shadow_macros_but_explicit_macro_imports_survive_runtime_definitions() {
    let mut h = host("(ns macros) (defmacro value [] 7)", &["value"]);
    let source = r#"(def value 3)
        (js/console.log value (value) (m/value)
          (let [value (fn [] 9)] (value))
          (let [value (fn [] 9)] (macros/value)))"#;
    assert_eq!(
        execute(&compile_with_macros(source, &mut h).unwrap()),
        "3 7 7 9 7\n"
    );
    assert_eq!(
        result(&compile("(def when (fn* [x] x)) (when 8)").unwrap()),
        "8\n"
    );
    assert_eq!(
        result(&compile("(let* [let (fn* [x] x)] (let 6))").unwrap()),
        "6\n"
    );
}

#[test]
fn macro_aliases_do_not_create_runtime_aliases_or_expose_interpreter_vars() {
    let s = Sources::new();
    s.write(
        "api.clj",
        "(ns api) (def runtime-only 40) (defmacro value [] 7)",
    );
    s.write("runtime.cljs", "(ns runtime) (def value 5)");
    s.write("main.cljs", "(ns main (:require [runtime :as a]) (:require-macros [api :as a])) (js/console.log a/value (a/value))");
    assert_eq!(execute(&s.compile("main").unwrap()), "5 7\n");
    s.write(
        "main.cljs",
        "(ns main (:require-macros [api :as a])) a/runtime-only",
    );
    assert!(
        s.compile("main")
            .unwrap_err()
            .message
            .contains("unknown namespace or alias a")
    );
    s.write(
        "main.cljs",
        "(ns main (:require [runtime :as a])) (a/value)",
    );
    // This resolves an ordinary runtime call; macro api/value was not imported.
    assert!(s.compile("main").unwrap().contains(".call(null"));
    let mut h = host(
        "(ns macros) (def hidden 33) (defmacro read-hidden [] hidden)",
        &["read-hidden"],
    );
    assert_eq!(
        result(&compile_with_macros("(read-hidden)", &mut h).unwrap()),
        "33\n"
    );
    assert!(compile_with_macros("macros/hidden", &mut h).is_err());
    assert!(compile_with_macros("m/read-hidden", &mut h).is_err());
}

#[test]
fn cljs_env_has_binding_records_context_namespace_and_unevaluated_form() {
    let mut h = host(
        r#"(ns macros)
      (defmacro inspect-env []
        (str (:context &env) "/" (:name (:ns &env)) "/" (ns-name *ns*) "/"
          (:op (get (:locals &env) 'x)) "/" (:local (get (:locals &env) 'x)) "/"
          (:arg-id (get (:locals &env) 'x)) "/" (contains? (:locals &env) 'self)))
      (defmacro syntax [x] (str (first &form) "/" x "/" (:line (meta &form))))
    "#,
        &["inspect-env", "syntax"],
    );
    assert_eq!(
        result(&compile_with_macros("(let [x (inspect-env)] x)", &mut h).unwrap()),
        ":expr/cljs.user/cljs.user////false\n"
    );
    assert_eq!(
        result(&compile_with_macros("(let [x 1] (inspect-env))", &mut h).unwrap()),
        ":return/cljs.user/cljs.user/:binding/:let//false\n"
    );
    assert_eq!(
        result(&compile_with_macros("((fn self [x] (inspect-env)) 1)", &mut h).unwrap()),
        ":return/cljs.user/cljs.user/:binding/:arg/0/true\n"
    );
    assert_eq!(
        result(&compile_with_macros("(syntax (undefined never-evaluated))", &mut h).unwrap()),
        "syntax/(undefined never-evaluated)/1\n"
    );
    let discarded = "(js/console.log (let [x 1] (js/console.log (inspect-env)) (inspect-env)))";
    assert_eq!(
        execute(&compile_with_macros(discarded, &mut h).unwrap()),
        ":expr/cljs.user/cljs.user/:binding/:let//false\n:return/cljs.user/cljs.user/:binding/:let//false\n"
    );
}

#[test]
fn macro_namespaces_load_once_with_clj_features_and_explicit_reload_is_observed() {
    let s = Sources::new();
    s.write(
        "macros.cljc",
        "(ns macros) #?(:clj (defmacro value [] 1) :cljs (defmacro value [] 9))",
    );
    s.write(
        "main.cljs",
        "(ns main (:require-macros [macros :refer [value]])) (js/console.log (value))",
    );
    let mut h = MacroHost::new();
    assert_eq!(execute(&s.compile_host("main", &mut h).unwrap()), "1\n");
    s.write("macros.cljc", "(ns macros) (defmacro value [] 2)");
    assert_eq!(execute(&s.compile_host("main", &mut h).unwrap()), "1\n");
    h.load_namespace("macros", Reload::Namespace).unwrap();
    assert_eq!(execute(&s.compile_host("main", &mut h).unwrap()), "2\n");
    assert_eq!(execute(&s.compile("main").unwrap()), "2\n");
    let mut isolated = MacroHost::new();
    assert!(compile_with_macros("(macros/value)", &mut isolated).is_err());
}

#[test]
fn macro_code_uses_clj_dependencies_and_caller_aliases_without_allowing_cljs_conditionals() {
    let s = Sources::new();
    s.write("helper.clj", "(ns helper) (defn select [x] x)");
    s.write(
        "macros.clj",
        "(ns macros (:require [helper :as h])) (defmacro identity-form [x] (h/select x))",
    );
    s.write("main.cljs", "(ns main (:require-macros [macros :refer [identity-form]])) (js/console.log (identity-form #?(:cljs 4 :clj 8)))");
    assert!(
        s.compile("main")
            .unwrap_err()
            .message
            .contains("ReaderConditional")
    );
    s.write(
        "macros.clj",
        "(ns macros (:require [helper :as h])) (defmacro keyword-name [x] (h/select (str x)))",
    );
    s.write("runtime.cljs", "(ns runtime)");
    s.write("main.cljs", "(ns main (:require [runtime :as r]) (:require-macros [macros :as m :refer [keyword-name]])) (js/console.log (keyword-name ::m/a) (keyword-name ::r/b) (keyword-name ::c))");
    assert_eq!(
        execute(&s.compile("main").unwrap()),
        ":macros/a :runtime/b :main/c\n"
    );
}

#[test]
fn returned_forms_keep_utf16_negative_zero_and_number_boundaries() {
    let mut h = host(
        r#"(ns macros) (defmacro text [] "\uD800")
        (defmacro negzero [] -0.0) (defmacro too-big [] 9007199254740992)
        (defmacro inner [n] 4) (defmacro outer [] '(inner 9007199254740992))"#,
        &["text", "negzero", "too-big", "inner", "outer"],
    );
    let js = compile_with_macros(
        "(js/console.log (.charCodeAt (text) 0) (js/Object.is (negzero) -0.0) (outer))",
        &mut h,
    )
    .unwrap();
    assert_eq!(execute(&js), "55296 true 4\n");
    assert_eq!(
        result(&compile_with_macros("(too-big)", &mut h).unwrap()),
        "9007199254740992\n"
    );
}

#[test]
fn generated_collections_remain_macro_data_until_used_as_runtime_expressions() {
    let mut h = host(
        "(ns macros) (defmacro inner [x] (if (= (:v x) :yes) 4 8)) (defmacro outer [] '(inner {:v :yes}))",
        &["inner", "outer"],
    );
    assert_eq!(
        result(&compile_with_macros("(outer)", &mut h).unwrap()),
        "4\n"
    );
}

#[test]
fn generated_diagnostics_point_to_call_sites_and_explain_unsupported_runtime() {
    let mut h = host(
        "(ns macros) (defmacro bad [] '(loop* [x 1] x)) (defmacro bad-character [] \\a) (defmacro explode [] (throw (ex-info \"broken\" {})))",
        &["bad", "bad-character", "explode"],
    );
    for (call, message) in [("(bad)", "generated by bad"), ("(explode)", "broken")] {
        let source = format!("; λ\n{call}");
        let error = compile_with_macros(&source, &mut h).unwrap_err();
        assert!(error.to_string().contains(message), "{error}");
        let light_cljs::CompileError::Analysis(error) = error else {
            panic!()
        };
        assert_eq!(error.span, 5..source.len());
    }
    for source in ["(fn [x] {:pre [x]} x)", "(fn ([x] x) ([] 1))"] {
        let error = compile(source).unwrap_err().to_string();
        assert!(error.contains("macro expansion"), "{source}: {error}");
    }
}

#[test]
fn macro_import_validation_and_loader_failures_are_located() {
    let s = Sources::new();
    s.write(
        "macros.clj",
        "(ns macros) (def value 1) (defmacro hidden {:private true} [] 4) (defmacro visible [] 5)",
    );
    for (header, message) in [
        ("(:require-macros [macros :refer [value]])", "public macro"),
        ("(:require-macros [macros :refer [hidden]])", "public macro"),
        (
            "(:require-macros [macros :refer [visible visible]])",
            "duplicate macro refer",
        ),
        (
            "(:require-macros [macros :as m] [macros :as m])",
            "duplicate macro alias",
        ),
        ("(:require-macros [missing :as m])", "MissingNamespace"),
        (
            "(:require-macros [macros :refer :all])",
            "vector of simple symbols",
        ),
    ] {
        s.write("main.cljs", &format!("(ns main {header}) 1"));
        let error = s.compile("main").unwrap_err();
        assert!(error.message.contains(message), "{error}");
        assert!(error.path.unwrap().ends_with("main.cljs"));
        assert!(error.span.is_some());
    }
    s.write(
        "main.cljs",
        "(ns main (:require-macros [macros :as m])) (m/visible)",
    );
    s.write("macros.cljc", "(ns macros) (defmacro visible [] 5)");
    assert!(
        s.compile("main")
            .unwrap_err()
            .message
            .contains("AmbiguousSources")
    );
}

#[test]
fn native_host_macros_use_the_same_form_env_and_arity_abi() {
    static MACRO: NativeDefinition = NativeDefinition {
        metadata: NativeMetadata {
            namespace: "host",
            name: "answer",
            arity: Arity::Exact(3),
            effects: NativeEffects::Pure,
            errors: &[],
        },
        callback: |c, args| {
            let env = args[1].get(&c.keyword(Name::new(None, "locals")))?.unwrap();
            let binding = env.get(&c.symbol(Name::new(None, "x")))?.unwrap();
            assert!(binding.get(&c.keyword(Name::new(None, "name")))?.is_some());
            Ok(args[2].clone())
        },
    };
    let mut h = MacroHost::new();
    h.register_macro(&MACRO);
    h.set_imports(
        "cljs.user",
        vec![MacroImport {
            namespace: "host".into(),
            alias: Some("h".into()),
            refers: vec![],
        }],
    )
    .unwrap();
    let source = "(let* [x 17] (h/answer x))";
    let syntax = parse(source).unwrap();
    let original = syntax.clone();
    let program = analyze_with_macros(source, &syntax, &mut h).unwrap();
    assert_eq!(
        syntax, original,
        "analysis must not mutate caller-owned syntax"
    );
    assert_eq!(result(&emit_js(&program)), "17\n");
    let sources = Sources::new();
    sources.write(
        "main.cljs",
        "(ns main (:require-macros [host :as h])) (let [x 19] (h/answer x))",
    );
    assert_eq!(
        result(&sources.compile_host("main", &mut h).unwrap()),
        "19\n"
    );
    assert!(
        compile_with_macros("(h/answer)", &mut h)
            .unwrap_err()
            .to_string()
            .contains("Arity")
    );
}

#[test]
fn recursive_and_growing_expansions_obey_depth_count_size_and_execution_limits() {
    let mut h = host(
        "(ns macros) (defmacro again [] '(do (again))) (defmacro one [] 1) (defmacro grow [] '(do 1 2 3 4)) (defmacro spin [] (loop [] (recur)))",
        &["again", "one", "grow", "spin"],
    );
    h.limits.expansion_depth = 8;
    assert!(
        compile_with_macros("(again)", &mut h)
            .unwrap_err()
            .to_string()
            .contains("depth limit")
    );
    h.limits.expansions = 2;
    assert!(
        compile_with_macros("(do (one) (one) (one))", &mut h)
            .unwrap_err()
            .to_string()
            .contains("expansion limit")
    );
    h.limits.generated_nodes = 3;
    assert!(
        compile_with_macros("(grow)", &mut h)
            .unwrap_err()
            .to_string()
            .contains("generated-node limit")
    );
    h.context_mut().set_resource_limits(ResourceLimits {
        fuel: Some(500),
        ..ResourceLimits::default()
    });
    assert!(
        compile_with_macros("(spin)", &mut h)
            .unwrap_err()
            .to_string()
            .contains("Fuel")
    );
    // Per-compilation counters are fresh after failure; no poisoned expansion cache.
    assert_eq!(
        result(&compile_with_macros("(one)", &mut h).unwrap()),
        "1\n"
    );
}

#[test]
fn macro_call_namespace_binding_is_restored_and_do_context_matches_cljs() {
    let mut h = host(
        "(ns macros) (defmacro context [] (str (:context &env)))",
        &["context"],
    );
    let before = h.context_mut().current_namespace();
    assert_eq!(
        execute(
            &compile_with_macros("(js/console.log (do 1 (context)) (do (context)))", &mut h)
                .unwrap()
        ),
        ":return :expr\n"
    );
    assert!(before.same_identity(&h.context_mut().current_namespace()));
    assert!(compile_with_macros("(context 1)", &mut h).is_err());
    assert!(before.same_identity(&h.context_mut().current_namespace()));
}

#[test]
fn runtime_caller_namespace_does_not_count_as_loaded_macro_code() {
    let s = Sources::new();
    s.write("same.cljs", "(ns same) (let [x 1] x)");
    s.write("same.clj", "(ns same) (defmacro value [] 42)");
    s.write(
        "main.cljs",
        "(ns main (:require-macros [same :refer [value]])) (value)",
    );
    let mut h = MacroHost::new();
    s.compile_host("same", &mut h).unwrap();
    assert_eq!(result(&s.compile_host("main", &mut h).unwrap()), "42\n");
}

#[test]
fn macro_namespace_effects_are_shared_once_per_host_not_across_default_compilations() {
    let s = Sources::new();
    s.write(
        "macros.clj",
        "(ns macros) (def counter (atom 0)) (defmacro next-value [] (swap! counter inc))",
    );
    s.write(
        "dep.cljs",
        "(ns dep (:require-macros [macros :refer [next-value]])) (def value (next-value))",
    );
    s.write("main.cljs", "(ns main (:require [dep :as d]) (:require-macros [macros :refer [next-value]])) (js/console.log d/value (next-value))");
    assert_eq!(execute(&s.compile("main").unwrap()), "1 2\n");
    assert_eq!(execute(&s.compile("main").unwrap()), "1 2\n");
    let mut h = MacroHost::new();
    assert_eq!(execute(&s.compile_host("main", &mut h).unwrap()), "1 2\n");
    assert_eq!(execute(&s.compile_host("main", &mut h).unwrap()), "3 4\n");
}

#[test]
fn macro_statistics_attribute_native_and_interpreted_expansion_work() {
    let mut h = host("(ns macros) (defmacro value [] '(let [x 3] x))", &["value"]);
    h.context_mut().set_macro_diagnostics(true);
    compile_with_macros("(value)", &mut h).unwrap();
    let stats = h.context_mut().macro_expansion_stats();
    let custom = stats
        .iter()
        .find(|s| s.name == Name::new(Some("macros"), "value"))
        .unwrap();
    assert_eq!(custom.expansions, 1);
    assert!(custom.generated_forms > 1);
    assert!(custom.definition.is_some());
    assert!(
        stats
            .iter()
            .any(|s| s.name == Name::new(Some("clojure.core"), "let"))
    );
}

#[test]
fn macro_import_effects_follow_runtime_dependency_analysis_order() {
    let s = Sources::new();
    s.write(
        "shared.clj",
        "(ns shared) (def state (atom 0)) (defmacro value [] @state)",
    );
    s.write(
        "b.cljs",
        "(ns b (:require-macros [shared :refer [value]])) (def x (value))",
    );
    s.write(
        "modify.clj",
        "(ns modify (:require [shared :as s])) (reset! s/state 9)",
    );
    s.write(
        "a.cljs",
        "(ns a (:require [b :as b]) (:require-macros modify)) (js/console.log b/x)",
    );
    assert_eq!(execute(&s.compile("a").unwrap()), "0\n");
}

#[test]
fn default_interpreter_user_identity_does_not_hide_user_macro_source() {
    let s = Sources::new();
    s.write("user.clj", "(ns user) (defmacro value [] 42)");
    s.write(
        "main.cljs",
        "(ns main (:require-macros [user :refer [value]])) (value)",
    );
    assert_eq!(result(&s.compile("main").unwrap()), "42\n");
}

#[test]
fn exhausted_expansion_depth_does_not_run_macro_effects() {
    let mut h = host(
        "(ns macros) (def counter (atom 0)) (defmacro effect [] (swap! counter inc))",
        &["effect"],
    );
    h.limits.expansion_depth = 0;
    assert!(
        compile_with_macros("(effect)", &mut h)
            .unwrap_err()
            .to_string()
            .contains("depth limit")
    );
    assert_eq!(
        h.context_mut()
            .eval_string("@macros/counter")
            .unwrap()
            .inspect(),
        light_cljs::interpreter::ValueView::Integer(0)
    );
}

#[test]
fn generated_vectors_and_keyword_names_execute_with_owned_semantic_values() {
    let mut h = host(
        "(ns macros) (defmacro data [] [:made/by-macro :other/x]) (defmacro key [] (keyword \"made\" \"answer\"))",
        &["data", "key"],
    );
    let source = "(js/console.log (count (data)) (name (key)) (namespace (key)) (name (nth (data) 1)) (= (key) :made/answer))";
    assert_eq!(
        execute(&compile_with_macros(source, &mut h).unwrap()),
        "2 answer made x true\n"
    );

    static SURROGATE: NativeDefinition = NativeDefinition {
        metadata: NativeMetadata {
            namespace: "host",
            name: "surrogate",
            arity: Arity::Exact(2),
            effects: NativeEffects::Pure,
            errors: &[],
        },
        callback: |c, _| Ok(c.keyword(Name::from_utf16(Some(&[0xd800]), &[0xd800]))),
    };
    h.register_macro(&SURROGATE);
    h.set_imports(
        "cljs.user",
        vec![MacroImport {
            namespace: "host".into(),
            alias: Some("h".into()),
            refers: vec![],
        }],
    )
    .unwrap();
    let source = "(let [k (h/surrogate)] (js/console.log (.charCodeAt (name k) 0) (.charCodeAt (namespace k) 0)))";
    assert_eq!(
        execute(&compile_with_macros(source, &mut h).unwrap()),
        "55296 55296\n"
    );
}

#[test]
fn direct_auto_keywords_use_the_same_macro_alias_precedence_as_macro_input() {
    let mut h = host(
        "(ns macros) (defmacro identity-form [x] x)",
        &["identity-form"],
    );
    assert_eq!(
        result(&compile_with_macros("(= ::m/x (identity-form ::m/x))", &mut h).unwrap()),
        "true\n"
    );
    assert_eq!(
        result(&compile_with_macros("(namespace ::m/x)", &mut h).unwrap()),
        "macros\n"
    );
    let sources = Sources::new();
    sources.write("runtime.cljs", "(ns runtime)");
    sources.write("macros.clj", "(ns macros) (defmacro identity-form [x] x)");
    sources.write("main.cljs", "(ns main (:require [runtime :as m]) (:require-macros [macros :as m])) (js/console.log (namespace ::m/x) (namespace (m/identity-form ::m/x)))");
    assert_eq!(
        execute(&sources.compile("main").unwrap()),
        "macros macros\n"
    );
}

#[test]
fn quoted_macro_values_preserve_symbols_effects_and_generated_provenance() {
    let mut h = host(
        "(ns macros) (def counter (atom 0)) (defmacro danger [] (swap! counter inc) 99) (defmacro data [] '(quote [unresolved-name (danger) a/x])) (defmacro invalid [] '(quote [ok \\a]))",
        &["danger", "data", "invalid"],
    );
    let source = "(js/console.log (name (nth (data) 0)) (name (first (nth (data) 1))) (= (nth (data) 2) 'a/x) (= '(danger) (list 'danger)))";
    assert_eq!(
        execute(&compile_with_macros(source, &mut h).unwrap()),
        "unresolved-name danger true true\n"
    );
    assert_eq!(
        h.context_mut()
            .eval_string("@macros/counter")
            .unwrap()
            .inspect(),
        light_cljs::interpreter::ValueView::Integer(0)
    );
    assert_eq!(
        result(&compile_with_macros("(nth (invalid) 1)", &mut h).unwrap()),
        "a\n"
    );
    assert_eq!(
        result(&compile("(let [[x & xs] [1 2 3]] (= [x xs] [1 '(2 3)]))").unwrap()),
        "true\n"
    );
}

#[test]
fn quoted_generated_symbols_preserve_lone_surrogates_but_executable_names_reject_them() {
    static QUOTED: NativeDefinition = NativeDefinition {
        metadata: NativeMetadata {
            namespace: "host",
            name: "quoted",
            arity: Arity::Exact(2),
            effects: NativeEffects::Pure,
            errors: &[],
        },
        callback: |c, _| {
            let quote = c.symbol(Name::new(None, "quote"));
            let value = c.symbol(Name::from_utf16(Some(&[0xd800]), &[0xdc00]));
            Ok(c.list(&[quote, value])?)
        },
    };
    static EXECUTABLE: NativeDefinition = NativeDefinition {
        metadata: NativeMetadata {
            namespace: "host",
            name: "executable",
            arity: Arity::Exact(2),
            effects: NativeEffects::Pure,
            errors: &[],
        },
        callback: |c, _| Ok(c.symbol(Name::from_utf16(Some(&[0xd800]), &[0xdc00]))),
    };
    let mut h = host("(ns macros)", &[]);
    h.register_macro(&QUOTED);
    h.register_macro(&EXECUTABLE);
    h.set_imports(
        "cljs.user",
        vec![MacroImport {
            namespace: "host".into(),
            alias: Some("h".into()),
            refers: vec![],
        }],
    )
    .unwrap();
    let source = "(let [s (h/quoted)] (js/console.log (.charCodeAt (name s) 0) (.charCodeAt (namespace s) 0)))";
    assert_eq!(
        execute(&compile_with_macros(source, &mut h).unwrap()),
        "56320 55296\n"
    );
    let error = compile_with_macros("(h/executable)", &mut h).unwrap_err();
    assert!(error.to_string().contains("non-Unicode executable symbol"));
}

#[test]
fn generated_maps_preserve_owned_children_order_keys_and_quoted_data() {
    let mut h = host(
        "(ns macros) (defmacro identity-form [x] x) (defmacro data [] {:a [1 2]}) (defmacro quoted [] '(quote {danger (unresolved 1)}))",
        &["identity-form", "data", "quoted"],
    );
    let entries = (0..16)
        .map(|i| format!("(f {}) (f {})", i * 2, i * 2 + 1))
        .collect::<Vec<_>>()
        .join(" ");
    let source = format!(
        "(let [f (fn* [x] (js/console.log x) x) m (identity-form {{{entries}}})] (js/console.log (count m) (= (:a (data)) [1 2]) (= (get (quoted) 'danger) '(unresolved 1))))"
    );
    let expected = (0..32).map(|i| format!("{i}\n")).collect::<String>() + "16 true true\n";
    assert_eq!(
        execute(&compile_with_macros(&source, &mut h).unwrap()),
        expected
    );
    let source = "(let* [f (fn* [x] (js/console.log x) x) a 1 b 1] (js/console.log (get (identity-form {a (f 2) b (f 3)}) 1)))";
    assert_eq!(
        execute(&compile_with_macros(source, &mut h).unwrap()),
        "2\n3\n3\n"
    );
    let source = "; λ\n(identity-form {:a missing})";
    let error = compile_with_macros(source, &mut h).unwrap_err();
    assert!(
        error.to_string().contains("unresolved symbol: missing"),
        "{error}"
    );
    let light_cljs::CompileError::Analysis(error) = error else {
        panic!()
    };
    assert_eq!(&source[error.span], "{:a missing}");
}

#[test]
fn generated_map_keys_keep_reader_name_parts_before_runtime_spelling_equality() {
    static MAP_NAMES: NativeDefinition = NativeDefinition {
        metadata: NativeMetadata {
            namespace: "host",
            name: "map-names",
            arity: Arity::Exact(2),
            effects: NativeEffects::Pure,
            errors: &[],
        },
        callback: |c, _| {
            let first = c.keyword(Name::new(None, "a/b"));
            let second = c.keyword(Name::new(Some("a"), "b"));
            Ok(c.map(&[(first, c.integer(1)), (second, c.integer(2))])?)
        },
    };
    let mut h = host("(ns macros)", &[]);
    h.register_macro(&MAP_NAMES);
    h.set_imports(
        "cljs.user",
        vec![MacroImport {
            namespace: "host".into(),
            alias: Some("h".into()),
            refers: vec![],
        }],
    )
    .unwrap();
    assert_eq!(
        result(&compile_with_macros("(count (h/map-names))", &mut h).unwrap()),
        "1\n"
    );
}

#[test]
fn generated_sets_preserve_members_source_effects_and_quoted_data() {
    let mut h = host(
        "(ns macros) (defmacro identity-form [x] x) (defmacro data [] #{:a [1 2]}) (defmacro quoted [] '(quote #{danger (unresolved 1)})) (defmacro ignore [x] nil)",
        &["identity-form", "data", "quoted", "ignore"],
    );
    let members = (0..16)
        .map(|i| format!("(f {i})"))
        .collect::<Vec<_>>()
        .join(" ");
    let source = format!(
        "(let [f (fn* [x] (js/console.log x) x) s (identity-form #{{{members}}})] (js/console.log (count s) (contains? (data) [1 2]) (contains? (quoted) '(unresolved 1))))"
    );
    let expected = (0..16).map(|i| format!("{i}\n")).collect::<String>() + "16 true true\n";
    assert_eq!(
        execute(&compile_with_macros(&source, &mut h).unwrap()),
        expected
    );
    let source = "(let* [f (fn* [x] (js/console.log x) x) a 1 b 1] (js/console.log (count (identity-form #{(f a) (f b)}))))";
    assert_eq!(
        execute(&compile_with_macros(source, &mut h).unwrap()),
        "1\n1\n1\n"
    );
    for source in [
        "(let [f (fn* [x] (js/console.log x) x)] (js/console.log (count #{(f 1) (f 1)})))",
        "(let* [f (fn* [x] (js/console.log x) x)] (js/console.log (count (identity-form #{(f 1) (f 1)}))))",
    ] {
        assert_eq!(
            execute(&compile_with_macros(source, &mut h).unwrap()),
            "1\n1\n1\n"
        );
    }
    for source in [
        "(identity-form #{1 1})",
        "(identity-form '#{x x})",
        "(ignore ^:m #{1 1})",
    ] {
        assert!(
            compile_with_macros(source, &mut h)
                .unwrap_err()
                .to_string()
                .contains("duplicate set member")
        );
    }
    let source = "; λ\n(identity-form #{:a missing})";
    let error = compile_with_macros(source, &mut h).unwrap_err();
    assert!(
        error.to_string().contains("unresolved symbol: missing"),
        "{error}"
    );
    let light_cljs::CompileError::Analysis(error) = error else {
        panic!()
    };
    assert_eq!(&source[error.span], "#{:a missing}");
}

#[test]
fn macros_generate_resolved_reductions_and_fixed_callbacks_without_native_execution() {
    let mut h = host(
        "(ns macros) (defmacro sum [xs] (list 'cljs.core/reduce 'cljs.core/+ 0 xs)) (defmacro early [xs] (list 'cljs.core/reduce '(fn* [a b] (cljs.core/reduced (cljs.core/+ a b))) 0 xs))",
        &["sum", "early"],
    );
    let source = "(let [reduce 99 + 88] (js/console.log (sum [1 2 3]) (early [4 5 6]) (cljs.core/reduce (fn [a b] (cljs.core/+ a b)) 0 [7 8])))";
    assert_eq!(
        execute(&compile_with_macros(source, &mut h).unwrap()),
        "6 4 15\n"
    );
    assert_eq!(
        result(&compile("(reduce (fn [a b] (+ a b)) 0 [1 2 3])").unwrap()),
        "6\n"
    );
    let acceptance = "(let [observe (fn [x] (js/console.log x))] (= [(reduce + [1 2 3]) (reduce + 10 [1 2 3]) (reduce + []) (reduce + 7 []) (reduce (fn [] 17) []) (reduce (fn [a b] (observe 99)) [5]) (reduce conj [] (list 1 2))] [6 16 0 7 17 5 [1 2]]))";
    assert_eq!(result(&compile(acceptance).unwrap()), "true\n");
}

#[test]
fn unsupported_generated_collection_program_forms_keep_file_macro_and_callsite_diagnostics() {
    let sources = Sources::new();
    for body in [
        "'(lazy-seq (list 1))",
        "'(defrecord Thing [x])",
        "'(defprotocol P (method [this]))",
        "'(fn* ([x] x) ([x y] y))",
    ] {
        sources.write(
            "bad/macros.clj",
            &format!("(ns bad.macros) (defmacro emit-bad [] {body})"),
        );
        let source = "(ns bad.main (:require-macros [bad.macros :as m]))\n; λ\n(m/emit-bad)";
        sources.write("bad/main.cljs", source);
        let error = sources.compile("bad.main").unwrap_err();
        assert!(error.message.contains("m/emit-bad"), "{body}: {error}");
        assert!(error.path.as_ref().unwrap().ends_with("bad/main.cljs"));
        assert_eq!(error.line_column, Some((3, 1)), "{body}: {error}");
        assert_eq!(
            error.span,
            Some(source.find("(m/emit-bad)").unwrap()..source.len())
        );
        let output = Command::new(env!("CARGO_BIN_EXE_light-cljs"))
            .args(["--compile", "--entry", "bad.main", "--source-root"])
            .arg(&sources.0)
            .output()
            .unwrap();
        assert!(!output.status.success(), "{body}");
        assert!(output.stdout.is_empty(), "{body}: partial JS");
        let diagnostic = String::from_utf8(output.stderr).unwrap();
        assert!(
            diagnostic.contains("bad/main.cljs:3:1:"),
            "{body}: {diagnostic}"
        );
        assert!(diagnostic.contains("m/emit-bad"), "{body}: {diagnostic}");
    }
}

#[test]
fn generated_qualified_operations_keep_core_identity_under_lexical_and_global_shadowing() {
    let sources = Sources::new();
    sources.write(
        "batch/macros.clj",
        include_str!("../examples/collections/batch/macros.clj"),
    );
    sources.write(
        "user/data.cljs",
        "(ns user.data) (def assoc (fn* [x] x)) (def vector (fn* [x] x))",
    );
    sources.write(
        "main.cljs",
        r#"(ns main (:require [cljs.core :as c] [user.data :as m])
      (:require-macros [batch.macros :as m]))
      (def assoc (fn* [x] x))
      (def saved c/get)
      (def get (fn* [x] x))
      (let [conj (fn* [x] x) reduce (fn* [x] x) + (fn* [x] x)
            changed (m/append-item {:items [1 2]} :items 3)]
        (js/console.log (c/reduce c/+ 0 (saved changed :items))
          (assoc 7) (get 8) (m/assoc 9) (m/vector 10) (conj 11) (reduce 12) (+ 13)
          (namespace ::m/x)))"#,
    );
    assert_eq!(
        execute(&sources.compile("main").unwrap()),
        "6 7 8 9 10 11 12 13 batch.macros\n"
    );
}

#[test]
fn collection_macro_compilation_obeys_cancellation_and_recovers_with_the_same_host() {
    let root = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("examples/collections");
    let mut host = MacroHost::new();
    let token = light_cljs::interpreter::CancellationToken::default();
    token.cancel();
    host.context_mut().set_cancellation_token(Some(token));
    let error = compile_namespace_with_macros("batch.main", std::slice::from_ref(&root), &mut host)
        .unwrap_err();
    assert!(error.to_string().contains("Cancelled"), "{error}");
    host.context_mut().set_cancellation_token(None);
    let js = compile_namespace_with_macros("batch.main", &[root], &mut host).unwrap();
    assert_eq!(
        execute(&format!("const run = {js}; console.log(typeof run);")),
        "data\nops\nmain\nfunction\n"
    );
}
